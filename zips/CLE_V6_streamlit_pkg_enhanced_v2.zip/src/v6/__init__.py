# ファイルパス: C:\lib_ana\src\v6\__init__.py
