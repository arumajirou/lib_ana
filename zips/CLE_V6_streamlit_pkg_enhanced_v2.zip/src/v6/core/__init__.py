# ファイルパス: C:\lib_ana\src\v6\core\__init__.py
