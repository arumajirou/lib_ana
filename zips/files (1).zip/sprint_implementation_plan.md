# LEAS V5.5 スプリント実装計画（詳細タスク分解）

## 🎯 V5.5 実装スコープ確定

### 実装対象機能（優先度Critical + High）

| ID | 機能名 | 工数見積 | 依存関係 | 担当想定 |
|---|---|---|---|---|
| **S-003** | ファイルシステムマッパー | 3日 | なし | Backend |
| **S-005** | パッケージ依存グラフ | 5日 | S-003 | Backend |
| **S-101** | インタラクティブ依存グラフ（強化） | 3日 | S-005 | Frontend |
| **U-002** | API類似度計算（強化） | 4日 | なし | ML/Backend |
| **U-004** | パッケージ自動分類 | 5日 | U-002 | ML |
| **U-101** | 認知的複雑度ヒートマップ | 4日 | なし | Backend |
| **Q-001** | ライセンスコンプライアンスチェック | 3日 | なし | Backend |
| **E-002** | Python API/CLI公開 | 8日 | 全機能 | Backend/DevOps |
| **O-003** | Self-checkコマンド | 3日 | なし | DevOps |
| **M-001** | 再帰的自己解析 | 2日 | E-002 | All |
| **M-003** | Universe俯瞰ダッシュボード | 5日 | S-003, U-004 | Frontend |

**合計工数**: 45日 → チーム3名で約15営業日（3週間）

---

## 📅 3週間スプリント計画

### Week 1: 基盤強化 Sprint

**目標**: ファイルシステム解析、依存関係グラフ、品質メトリクス基盤構築

#### Sprint 1.1: ファイルシステム・依存関係（Day 1-5）

##### Task S-003-1: ファイルシステムマッパー設計
- **担当**: Backend Dev
- **工数**: 0.5日
- **成果物**:
  ```python
  # src/v5/filesystem_mapper.py
  class FileSystemMapper:
      def scan_directory(self, package_path: Path) -> FileSystemTree
      def map_to_modules(self, fs_tree: FileSystemTree, modules: List[Node]) -> ModuleFSMapping
      def detect_inconsistencies(self, mapping: ModuleFSMapping) -> List[Inconsistency]
  ```
- **検証**: unit test with mock filesystem

##### Task S-003-2: ファイルスキャン実装
- **担当**: Backend Dev
- **工数**: 1日
- **詳細**:
  - pathlib.Path.rglob() でディレクトリ走査
  - .py, __init__.py, __pycache__ 識別
  - シンボリックリンク対応
  - 除外パターン（node_modules, .git等）適用
- **検証**: pytest with 5種類のパッケージ構造

##### Task S-003-3: モジュール対応マッピング
- **担当**: Backend Dev
- **工数**: 1日
- **詳細**:
  - pkgutil.iter_modules() 結果とファイルパス照合
  - 動的生成モジュール（C拡張等）の特定
  - namespace package対応
- **検証**: numpy, pandas, requestsで検証

##### Task S-003-4: UI統合（ツリービュー）
- **担当**: Frontend Dev
- **工数**: 0.5日
- **詳細**:
  - ipytree widget使用
  - ノードクリック→対応モジュール詳細ジャンプ
  - 不整合箇所の警告表示
- **検証**: UI動作確認

##### Task S-005-1: 依存関係抽出
- **担当**: Backend Dev
- **工数**: 2日
- **詳細**:
  ```python
  # src/lib_ana/dependency_analyzer.py
  class DependencyAnalyzer:
      def extract_from_metadata(self, package: str) -> List[Dependency]
      def extract_from_imports(self, source_code: str) -> List[str]
      def build_graph(self, dependencies: List[Dependency]) -> nx.DiGraph
  ```
  - pkg_resources.get_distribution().requires() 活用
  - AST import文解析（import, from import）
  - 循環依存検出（Tarjan's algorithm）
- **検証**: 5パッケージでグラフ構築成功

##### Task S-005-2: グラフ可視化強化
- **担当**: Frontend Dev
- **工数**: 1.5日
- **詳細**:
  - networkx → pyvis変換
  - ノード色分け（直接依存/間接依存）
  - エッジラベル（バージョン要件）
  - 循環依存の赤色強調
- **検証**: UI beautify check

##### Task S-101-1: 既存PyVisグラフ強化
- **担当**: Frontend Dev
- **工数**: 1.5日
- **詳細**:
  - physics設定最適化（repulsion, spring length）
  - ノードクリック→Inspector連携
  - フィルタリング（継承のみ、依存のみ）
  - エクスポート機能（HTML, PNG）
- **検証**: 100ノードグラフで動作確認

#### Sprint 1.2: 品質・意味解析（Day 6-10）

##### Task U-101-1: radon統合
- **担当**: Backend Dev
- **工数**: 1.5日
- **詳細**:
  ```python
  # src/lib_ana/complexity_analyzer.py
  class ComplexityAnalyzer:
      def analyze_file(self, filepath: Path) -> FileComplexity
      def calculate_scores(self, complexity: FileComplexity) -> QualityScore
  ```
  - radon.complexity.cc_visit() でCyclomatic Complexity算出
  - radon.metrics.mi_visit() でMaintainability Index
  - halstead metrics計算
- **検証**: 複雑なコード（深いネスト）で高スコア確認

##### Task U-101-2: ヒートマップ可視化
- **担当**: Frontend Dev
- **工数**: 1.5日
- **詳細**:
  - plotly.express.imshow() 使用
  - x軸: モジュール, y軸: メトリクス種類
  - 色スケール: green (低複雑度) → red (高複雑度)
  - ツールチップ: 詳細スコア表示
- **検証**: UI確認

##### Task U-004-1: カテゴリ分類器実装
- **担当**: ML Engineer
- **工数**: 2.5日
- **詳細**:
  ```python
  # src/lib_ana/package_classifier.py
  class PackageClassifier:
      def __init__(self):
          self.keyword_map = self._load_keyword_map()
      
      def classify(self, package_name: str, summary: str) -> List[Category]
      def _load_keyword_map(self) -> Dict[str, List[str]]
  ```
  - キーワードマッチング（scikit-learn, pytorch → ML）
  - PyPI category情報活用
  - TF-IDF + KNNで類似パッケージのカテゴリ推定
- **検証**: 50パッケージで精度>85%

##### Task U-004-2: UI統合
- **担当**: Frontend Dev
- **工数**: 1日
- **詳細**:
  - パッケージリストにカテゴリタグ表示
  - カテゴリフィルタ機能
  - カテゴリ別集計グラフ
- **検証**: UI確認

##### Task Q-001-1: ライセンス抽出
- **担当**: Backend Dev
- **工数**: 1.5日
- **詳細**:
  ```python
  # src/lib_ana/license_checker.py
  class LicenseChecker:
      def extract_license(self, package: str) -> Optional[License]
      def check_compatibility(self, licenses: List[License], project_license: str) -> CompatibilityReport
  ```
  - pkg_resources.get_distribution().get_metadata('METADATA')
  - license-expression ライブラリで正規化
  - 互換性マトリクス（MIT, Apache, GPL等）
- **検証**: 10パッケージでライセンス抽出成功

##### Task Q-001-2: UI統合
- **担当**: Frontend Dev
- **工数**: 1日
- **詳細**:
  - ライセンス一覧表示（パッケージ別）
  - 互換性警告表示（赤/黄/緑）
  - レポート出力（CSV, HTML）
- **検証**: UI確認

##### Task O-003-1: ヘルスチェック実装
- **担当**: DevOps
- **工数**: 2日
- **詳細**:
  ```python
  # src/v5/health_checker.py
  class HealthChecker:
      def check_dependencies(self) -> CheckResult
      def check_filesystem(self) -> CheckResult
      def check_permissions(self) -> CheckResult
      def check_external_tools(self) -> CheckResult  # radon, black等
      def generate_report(self, results: List[CheckResult]) -> Report
  ```
  - 必須ライブラリインポート確認
  - ディレクトリ書込権限確認
  - 外部コマンド（radon, black, isort）存在確認
- **検証**: 正常環境・異常環境両方で動作確認

##### Task O-003-2: CLI統合
- **担当**: DevOps
- **工数**: 0.5日
- **詳細**:
  - `leas self-check` コマンド実装
  - 結果を表形式で出力
  - 修復提案表示（pip install xxx）
- **検証**: CLI動作確認

---

### Week 2: API/CLI・メタ認知 Sprint

**目標**: Python API/CLI公開、自己解析機能、俯瞰ダッシュボード

#### Sprint 2.1: Python API設計（Day 1-3）

##### Task E-002-1: API設計・仕様策定
- **担当**: Backend Lead + Architect
- **工数**: 1日
- **成果物**:
  ```python
  # API設計例
  from leas import Analyzer, Config
  
  # 基本使用
  analyzer = Analyzer(config=Config.from_yaml('config.yml'))
  result = analyzer.analyze(['pandas', 'numpy'])
  result.export_html('report.html')
  
  # 詳細制御
  result = analyzer.analyze(
      packages=['scikit-learn'],
      modes=['ast', 'runtime'],
      timeout=60,
      exclude_patterns=['*.tests']
  )
  
  # 検索
  apis = result.search(query='DataFrame', top_k=10)
  similar = result.find_similar(api_fqn='pandas.DataFrame.merge', top_k=5)
  ```
- **検証**: API review meeting

##### Task E-002-2: コア抽象化リファクタリング
- **担当**: Backend Dev × 2
- **工数**: 3日
- **詳細**:
  - LibraryAnalyzerV5を非UI依存に分離
  - CognitiveLibraryUIV5からPresentation層抽出
  - データクラス（AnalysisResult）のimmutable化
  - 循環参照除去
- **検証**: 既存Notebook動作保証 + unit test

##### Task E-002-3: CLI実装
- **担当**: DevOps + Backend
- **工数**: 2.5日
- **詳細**:
  ```bash
  # CLI例
  leas analyze pandas numpy --mode ast --output report.html
  leas search "load csv" --package pandas
  leas diff snapshot_v1.json snapshot_v2.json
  leas export result.json --format excel
  ```
  - Click framework使用
  - カラフルな進捗表示（rich/click）
  - エラーハンドリング・ヘルプ充実
- **検証**: 10コマンドパターンでE2Eテスト

##### Task E-002-4: ドキュメント作成
- **担当**: All（分担）
- **工数**: 1.5日
- **成果物**:
  - API reference (Sphinx autodoc)
  - CLI reference (--help + README)
  - Quick start guide
  - Example notebooks
- **検証**: Documentation review

#### Sprint 2.2: メタ認知機能（Day 4-8）

##### Task M-001-1: 自己解析設計
- **担当**: Backend Lead
- **工数**: 0.5日
- **詳細**:
  - 対象モジュール: src/v5/, src/lib_ana/
  - 除外: tests/, __pycache__
  - 出力: self_analysis_report.html
- **検証**: 設計レビュー

##### Task M-001-2: ブートストラップ実装
- **担当**: Backend Dev
- **工数**: 1日
- **詳細**:
  ```python
  # 自己解析スクリプト
  from leas import Analyzer, Config
  
  config = Config(
      target_packages=['leas'],  # 自分自身
      analysis_modes=['ast', 'runtime'],
      exclude_patterns=['tests/*', 'docs/*']
  )
  
  analyzer = Analyzer(config)
  result = analyzer.analyze_self()
  result.export_html('dogfooding_report.html')
  ```
  - インポート循環対策（遅延インポート）
  - 実行中モジュール除外
- **検証**: 自己解析成功

##### Task M-001-3: 継続的ドッグフーディング
- **担当**: All（ローテーション）
- **工数**: 0.5日/週（継続）
- **詳細**:
  - 週次で自己解析実行
  - 発見された問題をIssue化
  - 改善サイクル確立
- **検証**: Issueトラッキング

##### Task M-003-1: ダッシュボード設計
- **担当**: Frontend Lead + UX
- **工数**: 1日
- **成果物**: Figma mockup
- **内容**:
  - KPIカード: 総パッケージ数、総API数、解析成功率
  - カテゴリ分布（円グラフ）
  - 複雑度分布（ヒストグラム）
  - ライセンス分布（バーチャート）
  - 最近の解析履歴（テーブル）
- **検証**: UX review

##### Task M-003-2: ダッシュボード実装
- **担当**: Frontend Dev × 2
- **工数**: 3日
- **詳細**:
  - ipywidgets.GridBox レイアウト
  - plotly グラフ埋込
  - リアルタイム更新（Observable pattern）
  - フィルタリング連携
- **検証**: UI動作確認

##### Task M-003-3: データ集計ロジック
- **担当**: Backend Dev
- **工数**: 1.5日
- **詳細**:
  ```python
  # src/v5/dashboard_aggregator.py
  class DashboardAggregator:
      def aggregate_universe_stats(self, result: AnalysisResult) -> UniverseStats
      def calculate_trends(self, history: List[AnalysisResult]) -> TrendData
  ```
  - スナップショット間差分計算
  - トレンド分析（成長率、変更頻度）
- **検証**: unit test

##### Task M-003-4: エクスポート機能
- **担当**: Backend Dev
- **工数**: 0.5日
- **詳細**:
  - ダッシュボード→PDF export
  - グラフ→PNG export
  - 統計データ→CSV export
- **検証**: エクスポート成功確認

---

### Week 3: 統合・テスト・ドキュメント Sprint

**目標**: 全機能統合、E2Eテスト、ドキュメント完成

#### Sprint 3.1: 統合テスト（Day 1-3）

##### Task INT-001: シナリオテスト作成
- **担当**: QA + Backend
- **工数**: 1.5日
- **シナリオ例**:
  ```python
  # tests/integration/test_e2e_workflow.py
  def test_full_analysis_workflow():
      # 1. pip list読込
      inventory = load_pip_list('tests/fixtures/pip_list.txt')
      
      # 2. 解析実行
      analyzer = Analyzer()
      result = analyzer.analyze(inventory.get_package_names()[:5])
      
      # 3. 検索
      apis = result.search('read')
      assert len(apis) > 0
      
      # 4. 類似検索
      similar = result.find_similar(apis[0].fqn)
      assert len(similar) > 0
      
      # 5. コード生成
      code = result.generate_code(apis[0])
      assert 'import' in code
      
      # 6. エクスポート
      result.export_html('output.html')
      assert Path('output.html').exists()
  ```
- **検証**: CI passing

##### Task INT-002: パフォーマンステスト
- **担当**: Backend + DevOps
- **工数**: 1日
- **詳細**:
  ```python
  @pytest.mark.benchmark
  def test_analysis_performance():
      analyzer = Analyzer()
      result = analyzer.analyze(['numpy', 'pandas'])
      # Assert: < 300 seconds
  ```
  - pytest-benchmark使用
  - 目標値確認（前述のベンチマーク基準）
  - ボトルネック特定（cProfile）
- **検証**: ベンチマーク合格

##### Task INT-003: 互換性テスト
- **担当**: DevOps
- **工数**: 0.5日
- **詳細**:
  - Python 3.9, 3.10, 3.11, 3.12でテスト
  - Ubuntu, macOS, Windowsで確認
  - tox使用
- **検証**: CI matrix passing

#### Sprint 3.2: ドキュメント完成（Day 4-6）

##### Task DOC-001: API Referenceビルド
- **担当**: Backend Dev
- **工数**: 1日
- **詳細**:
  - Sphinx autodoc設定
  - Google-style docstring統一
  - HTML + PDF生成
  - ReadTheDocs統合
- **検証**: Documentation build success

##### Task DOC-002: Tutorial作成
- **担当**: All（分担）
- **工数**: 1.5日
- **成果物**:
  - Getting Started (30分で完結)
  - Advanced Usage (カスタマイズ)
  - Troubleshooting Guide
  - Example Notebooks × 5
- **検証**: External review（社内他チーム）

##### Task DOC-003: CHANGELOG・Release Notes
- **担当**: PM + Lead
- **工数**: 0.5日
- **成果物**:
  - CHANGELOG.md (V5.0 → V5.5差分)
  - Release notes (ハイライト)
  - Migration guide (V5 → V5.5)
- **検証**: Stakeholder review

#### Sprint 3.3: リリース準備（Day 7-8）

##### Task REL-001: パッケージング
- **担当**: DevOps
- **工数**: 0.5日
- **詳細**:
  - setup.py / pyproject.toml更新
  - wheel/sdist ビルド
  - PyPI test upload
- **検証**: pip install成功

##### Task REL-002: CI/CD設定
- **担当**: DevOps
- **工数**: 0.5日
- **詳細**:
  - GitHub Actions workflow更新
  - 自動テスト（全Sprint）
  - タグpush → PyPI自動公開
- **検証**: テストリリース成功

##### Task REL-003: セキュリティスキャン
- **担当**: Security + DevOps
- **工数**: 0.5日
- **詳細**:
  - bandit（コードセキュリティ）
  - safety（依存脆弱性）
  - CodeQL（静的解析）
- **検証**: Critical問題0件

##### Task REL-004: リリースノート公開
- **担当**: PM
- **工数**: 0.25日
- **詳細**:
  - GitHub Release作成
  - ブログポスト公開
  - 社内アナウンス
- **検証**: 公開完了

---

## 📊 リソース配分・役割分担

### チーム構成（想定）

| Role | 人数 | 主要担当機能 | スキルセット |
|------|-----|------------|------------|
| **Backend Dev** | 2名 | S-003, S-005, U-101, Q-001, E-002コア | Python, AST, networkx, radon |
| **Frontend Dev** | 1名 | S-101, U-101 UI, M-003 | ipywidgets, plotly, pyvis, UX |
| **ML Engineer** | 1名 | U-004, U-002強化 | scikit-learn, TF-IDF, 分類 |
| **DevOps** | 0.5名 | O-003, E-002 CLI, CI/CD | Click, pytest, GitHub Actions |
| **Lead/Architect** | 0.5名 | 設計レビュー, E-002設計, M-001 | アーキテクチャ, API設計 |

**Total**: 5 FTE

### 工数配分（合計45日 → 3週間）

| Week | Backend | Frontend | ML | DevOps | Lead | 合計 |
|------|---------|----------|----|----|------|------|
| Week 1 | 12日 | 5.5日 | 2.5日 | 2.5日 | 2日 | 24.5日 |
| Week 2 | 7日 | 4日 | 0日 | 3日 | 1.5日 | 15.5日 |
| Week 3 | 3日 | 0日 | 0日 | 2日 | 1日 | 6日 |
| **Total** | **22日** | **9.5日** | **2.5日** | **7.5日** | **4.5日** | **46日** |

チーム5名×5日/週×3週=75人日
計画46日 → **稼働率61%**（余裕あり）

---

## 🎯 マイルストーン・検証基準

### M5.5-1: Week 1完了時（基盤構築完了）

**検証項目:**
- [ ] ファイルシステムマッパー動作（3パッケージ）
- [ ] 依存グラフ生成成功（networkx）
- [ ] 複雑度ヒートマップ表示
- [ ] ライセンスチェック動作
- [ ] self-checkコマンド動作
- [ ] 全unit test passing (coverage >75%)

**判定基準**: 上記6項目全て✅で合格

### M5.5-2: Week 2完了時（API/メタ認知完了）

**検証項目:**
- [ ] Python API経由で解析実行可能
- [ ] CLI 10コマンド動作
- [ ] 自己解析レポート生成
- [ ] Universe俯瞰ダッシュボード表示
- [ ] API documentation生成
- [ ] 全integration test passing

**判定基準**: 上記6項目全て✅で合格

### M5.5-3: Week 3完了時（リリース準備完了）

**検証項目:**
- [ ] E2Eシナリオテスト全合格
- [ ] パフォーマンスベンチマーク達成
- [ ] Python 3.9-3.12動作確認
- [ ] ドキュメント完成（Tutorial含む）
- [ ] PyPI test環境アップロード成功
- [ ] セキュリティスキャンCritical 0件

**判定基準**: 上記6項目全て✅でリリース承認

---

## ⚠️ リスクと緩和策（実装レベル）

| リスク | 影響 | 確率 | 緩和策 | Owner |
|--------|------|------|--------|-------|
| **Week 1遅延** | スケジュール全体遅延 | 中 | バッファ1日確保、優先度再評価 | PM |
| **E-002リファクタ複雑化** | Week 2遅延 | 高 | 最小限変更に絞る、V6で完全化 | Backend Lead |
| **自己解析の循環インポート** | M-001失敗 | 中 | 遅延インポート、別プロセス実行 | Backend Dev |
| **パフォーマンステスト不合格** | リリース延期 | 低 | Week 1で仮測定、早期最適化 | Backend Dev |
| **ドキュメント作成遅延** | リリース品質低下 | 中 | 並行作業、外部レビュー早期化 | All |

---

## 📋 デイリースタンドアップ・週次レビュー

### Daily Standup（15分）

**形式**: Slack + 週2回対面（火・木）

**確認事項:**
- 昨日完了タスク
- 今日予定タスク
- ブロッカー・依存関係

### Weekly Review（60分）

**Week 1 Review:**
- マイルストーンM5.5-1達成確認
- デモ: ファイルマッパー、複雑度ヒートマップ
- 振返り: KPT（Keep, Problem, Try）

**Week 2 Review:**
- マイルストーンM5.5-2達成確認
- デモ: Python API, 自己解析, ダッシュボード
- 振返り: KPT

**Week 3 Review:**
- マイルストーンM5.5-3達成確認
- リリース判定会議
- 振返り: 3週間総括、V6への引継ぎ

---

## 🚀 V5.5 → V6 移行計画（プレビュー）

### V6で実装予定の機能（4週間想定）

| カテゴリ | 機能ID | 機能名 | 工数見積 |
|---------|-------|--------|---------|
| 構造 | S-102 | ASTビジュアライザ | 5日 |
| 意味 | U-005 | 型推論ビジュアライザ | 4日 |
| 意味 | U-102 | AI要約ジェネレータ | 5日 |
| 生成 | G-101 | テストケース生成 | 6日 |
| 品質 | Q-102 | 自己修復メカニズム | 5日 |
| 拡張 | E-101 | Analyzerプラグイン | 6日 |
| 運用 | O-101 | 自動ドキュメント | 3日 |

**合計**: 34日 → 4週間スプリント

### V5.5でV6準備すべき項目

- [ ] プラグインインターフェース基底クラス作成
- [ ] LLM統合の設定項目追加（API key管理）
- [ ] テストフレームワーク拡張（hypothesis統合）
- [ ] ドキュメント生成パイプライン設計

---

## 📈 成功指標（KPI）

### 開発プロセスKPI

| 指標 | 目標 | 測定方法 |
|------|------|---------|
| スプリント完遂率 | 100% | Task完了数/計画数 |
| テストカバレッジ | >80% | pytest-cov |
| バグ密度 | <5 bugs/KLOC | 発見バグ数÷コード行数 |
| Code Review時間 | <2日 | PR作成→承認 |
| ドキュメント完成度 | 100% | チェックリスト |

### 機能品質KPI

| 指標 | 目標 | 測定方法 |
|------|------|---------|
| 解析成功率 | >95% | 成功パッケージ数/総数 |
| 複雑度分析精度 | radon互換 | 手動検証10ファイル |
| ライセンス検出率 | >90% | 検出数/pip list数 |
| API応答時間 | <1秒 | pytest-benchmark |
| CLI使いやすさ | >4/5 | 社内ユーザー評価 |

---

## 🎓 次アクション（実装開始前の準備）

### 今すぐ実施（Before Sprint Start）

1. **環境準備**（DevOps, 0.5日）
   - [ ] GitHub Project作成、Issue template設定
   - [ ] CI/CD基盤確認（GitHub Actions動作）
   - [ ] 開発環境統一（Python 3.11, 依存ライブラリ）

2. **設計レビュー**（All, 0.5日）
   - [ ] E-002 API設計レビュー会議
   - [ ] M-003 ダッシュボードモックレビュー
   - [ ] リスク緩和策の最終確認

3. **タスク詳細化**（Lead, 0.5日）
   - [ ] 各TaskをGitHub Issueに登録
   - [ ] 依存関係をIssue間でリンク
   - [ ] 担当者アサイン

### Week 1 Day 1 朝（Sprint Kickoff）

- **Sprint Planning Meeting**（90分）
  - スプリント目標共有
  - タスクブレークダウン確認
  - 質問・懸念事項解消
  - チーム士気向上

**準備完了したら、即座にSprint開始！** 🚀

---

## 📝 結論

本スプリント計画により:

1. **具体性**: 各タスクを0.5-3日粒度で分解、即座に着手可能
2. **実現可能性**: 工数46日、3週間で稼働率61%、余裕あり
3. **リスク管理**: 各WeekでMilestone設定、早期問題検出
4. **継続性**: V6へのスムーズな移行計画組込

**最優先アクション**: Sprint開始前準備3項目（環境・レビュー・Issue化）を1日で完了し、Week 1 Sprint Kickoff実施！
