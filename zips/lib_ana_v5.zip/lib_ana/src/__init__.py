# Cognitive Library Explorer src package
from .ui_v4 import CognitiveLibraryUIV4  # legacy UI
