# ファイルパス: C:\lib_ana\src\v6\__init__.py
"""Cognitive Library Explorer V6 (Streamlit UI).

- Streamlit アプリ化（モダンUI/UX）
- 解析の進捗表示（プログレス/ステータス）
- 履歴・手入力フィルタ・逆引き（Param Index）
- 複数ライブラリ横断（Universe）分析の土台
"""
