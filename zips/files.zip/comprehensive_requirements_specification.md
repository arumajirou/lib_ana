# Python ライブラリ解析システム 統合要件定義書

**プロジェクト名**: Library Explorer & Analysis System (LEAS)  
**バージョン**: V5 (統合版)  
**作成日**: 2026年2月5日  
**対象範囲**: ライブラリ構造解析、API探索、値候補推定、コード生成、可視化

---

## 📋 目次

1. [プロジェクト概要](#1-プロジェクト概要)
2. [システムアーキテクチャ](#2-システムアーキテクチャ)
3. [機能要件](#3-機能要件)
4. [非機能要件](#4-非機能要件)
5. [データモデル](#5-データモデル)
6. [UI/UX要件](#6-uiux要件)
7. [実装計画](#7-実装計画)
8. [テスト戦略](#8-テスト戦略)
9. [リスクと対策](#9-リスクと対策)

---

## 1. プロジェクト概要

### 1.1 目的

未知のPythonライブラリを**最短で正しく理解**し、**実行可能なコードまで生成**できる統合探索システムを提供する。

**3つの核心価値**:
1. **場所の理解**: APIがどこにあるか（階層構造）
2. **使い方の理解**: 引数に何を入れるか（型・デフォルト・値候補）
3. **関係の理解**: 関連APIは何か（継承・依存・類似）

### 1.2 ターゲットユーザー

- **データサイエンティスト**: 新しい機械学習ライブラリの習得
- **ソフトウェアエンジニア**: 複雑なフレームワークの理解と統合
- **研究者**: 最新のPythonパッケージの評価と利用
- **初学者**: ライブラリの全体像把握とサンプルコード生成

### 1.3 現状の課題と解決アプローチ

| 課題 | 現状の問題 | 解決策 |
|------|-----------|--------|
| **API発見の困難** | 継承メソッド・外部再エクスポートの混入 | 定義元(origin)ベースのフィルタリング |
| **引数値の不明確** | 型ヒントだけでは実際の値がわからない | 値候補生成エンジン(確度付き) |
| **階層構造の崩壊** | 文字列ベースの親子推測で誤分類 | parent_id による厳密な階層管理 |
| **学習曲線の高さ** | 動くコードまでの道のりが長い | サンプルコード＋データ自動生成 |
| **可視化の粗さ** | Type別の塊で構造が見えない | モジュール階層を保持したSunburst/Mermaid |

---

## 2. システムアーキテクチャ

### 2.1 システム構成図

```
┌─────────────────────────────────────────────────────────────┐
│                     User Interface Layer                    │
│  ┌──────────┬──────────┬──────────┬──────────┬──────────┐  │
│  │Dashboard │Explorer  │Inspector │CodeGen   │Export    │  │
│  │(統計)    │(5階層Nav)│(詳細表示)│(コード生成)│(出力)    │  │
│  └──────────┴──────────┴──────────┴──────────┴──────────┘  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    Analysis Engine Layer                     │
│  ┌─────────────────────┬─────────────────────┬────────────┐ │
│  │ AST Analyzer        │ Runtime Analyzer    │ Hybrid     │ │
│  │ (静的解析)           │ (動的解析)          │ (統合)     │ │
│  └─────────────────────┴─────────────────────┴────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                     Data Processing Layer                    │
│  ┌──────────┬──────────┬──────────┬──────────┬──────────┐  │
│  │Feature   │Value     │Similarity│Cluster   │Taxonomy  │  │
│  │Extraction│Candidate │Analysis  │Analysis  │Engine    │  │
│  └──────────┴──────────┴──────────┴──────────┴──────────┘  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                      Storage Layer                           │
│  ┌──────────┬──────────┬──────────┬──────────┬──────────┐  │
│  │Cache     │Snapshot  │Config    │Logs      │Exports   │  │
│  │(JSON)    │(JSON/PKL)│(YAML)    │(TXT)     │(CSV/HTML)│  │
│  └──────────┴──────────┴──────────┴──────────┴──────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 モジュール構成

```
C:\lib_ana\
├── lib.ipynb                     # メインUI (Jupyter Notebook)
├── src\
│   ├── v5\                       # V5実装（最新版）
│   │   ├── __init__.py
│   │   ├── models_v5.py          # データモデル
│   │   ├── analyzer_v5.py        # 解析エンジン
│   │   ├── ui_v5.py              # メインUI
│   │   ├── mermaid_render_v5.py  # Mermaid描画
│   │   ├── mermaid_export_v5.py  # Mermaid HTML出力
│   │   ├── codegen_v5.py         # コード生成
│   │   ├── sample_data_factory_v5.py  # サンプルデータ生成
│   │   ├── taxonomy_v5.py        # API分類
│   │   ├── package_catalog_v5.py # パッケージカタログ
│   │   └── ui_html_v5\           # HTML/JSフォールバック
│   │
│   ├── lib_ana\                  # pip list解析系
│   │   ├── io_piplist.py         # pip list読み込み
│   │   ├── extract_ast.py        # AST抽出
│   │   ├── extract_libcst.py     # LibCST抽出（詳細）
│   │   ├── extract_runtime.py    # Runtime抽出
│   │   ├── features.py           # 特徴量生成
│   │   ├── similarity.py         # 類似度計算
│   │   ├── cluster.py            # クラスタリング
│   │   ├── exporters.py          # エクスポート
│   │   ├── cache_store.py        # キャッシュ管理
│   │   ├── logging_util.py       # ログ管理
│   │   └── ui_widgets.py         # UI補助
│   │
│   └── common\                   # 共通ユーティリティ
│       ├── config.py             # 設定管理
│       ├── validators.py         # バリデーション
│       └── utils.py              # 汎用関数
│
├── configs\
│   ├── settings.json             # アプリケーション設定
│   └── api_overrides.yml         # API面カスタマイズ
│
├── data\                         # 入力データ
│   └── sample\
│
├── cache\                        # キャッシュディレクトリ
│
├── outputs\                      # 出力ディレクトリ
│   ├── v5\
│   │   ├── {library}\
│   │   │   ├── analysis.json
│   │   │   ├── diagram.html
│   │   │   └── samples\
│   │   └── reports\
│   │
│   ├── api_tables\
│   ├── artifacts\
│   └── exports\
│
└── logs\                         # ログディレクトリ
```

---

## 3. 機能要件

### 3.1 Import & Inventory Management (台帳管理)

**FR-1.1 pip list読み込み**
- **入力形式**: 
  - ファイル形式: `pip list` コマンド出力（columns形式）
  - 直接ペースト: テキストエリア入力
- **正規化処理**:
  - 改行コード統一（CRLF→LF）
  - NBSP（非改行スペース）の除去
  - 空行・ヘッダー行の処理
- **パース結果**: `packages_inventory` DataFrame
  - 列: `package`, `version`, `editable_path`, `is_editable`
- **エラーハンドリング**: パース失敗行を `errors` テーブルに記録

**FR-1.2 台帳プロファイル**
- 統計情報表示:
  - 総パッケージ数
  - editable パッケージ数
  - バージョン重複
  - 欠損値
- サマリーカード表示（UI）

**FR-1.3 台帳エクスポート**
- フォーマット: CSV, Excel, JSON
- 出力先: `outputs/exports/`
- ファイル命名規則: `packages_{timestamp}.{ext}`

### 3.2 Library Analysis (ライブラリ解析)

**FR-2.1 解析対象選択**
- UIでパッケージ選択（複数選択可）
- フィルタ機能:
  - キーワード検索
  - editable のみ
  - バージョン範囲
- 選択セット保存・復元

**FR-2.2 AST解析（静的解析）**
- **抽出対象**:
  - モジュール階層（pkgutil.walk_packages）
  - クラス定義（ast.ClassDef）
  - 関数定義（ast.FunctionDef, ast.AsyncFunctionDef）
  - メソッド定義（クラス内関数）
- **抽出情報**:
  - 完全修飾名（FQN: Fully Qualified Name）
  - 定義位置（ファイルパス、行番号）
  - Docstring
  - デコレータ
- **親子関係**:
  - `parent_id` による厳密な階層管理
  - 文字列contains検索の禁止
- **失敗処理**:
  - パースエラーを `errors` テーブルに記録
  - 処理継続（部分失敗許容）

**FR-2.3 Runtime解析（動的解析）**
- **前提条件**:
  - ユーザーが明示的にON
  - import副作用リスクの警告表示
- **ブラックリスト機能**:
  - 危険なパッケージを除外（ユーザー設定可能）
  - デフォルト: `tensorflow`, `torch` など重いライブラリ
- **タイムアウト設定**:
  - 1パッケージあたり最大30秒
- **抽出情報**:
  - `inspect.signature()` によるシグネチャ
  - 型ヒント（annotation）
  - デフォルト値
  - 引数種別（POSITIONAL_ONLY, KEYWORD_ONLY等）
  - 継承関係（`inspect.getmro()`）
  - プロパティ（`@property`）

**FR-2.4 ハイブリッド解析**
- ASTとRuntimeの統合:
  - AST: 構造・位置情報（常に安全）
  - Runtime: シグネチャ・Doc詳細（ONの場合のみ）
- 優先順位:
  1. Runtime情報（利用可能な場合）
  2. AST情報（フォールバック）
  3. 空値（どちらも取得失敗）

**FR-2.5 継承メンバー制御**
- **デフォルト**: `cls.__dict__` のみ（定義されたメンバーのみ）
- **オプション**: `include_inherited_members=True` で継承込み
- 外部再エクスポート除外:
  - `__module__` チェックで定義元を判定
  - `include_external_reexports=False` で除外

**FR-2.6 引数デフォルト値・種別の抽出**
- **ParamDefaults**: 引数名→デフォルト値のマップ
- **ParamKinds**: 引数名→種別（Parameter.kind）のマップ
- **global_defaults**: 同名引数のデフォルト値を全体集計
  - 例: `verbose=False` が100個のメソッドで使われている → 候補値として提示

### 3.3 Value Candidate Generation (値候補生成)

**FR-3.1 値候補の生成ソース（優先順・確度付き）**

| ソース | 抽出元 | 確度 | 例 |
|--------|--------|------|-----|
| `default` | デフォルト値 | 0.95 | `verbose=False` → `False` |
| `typing.Literal` | 型ヒント | 0.90 | `Literal['mean', 'median']` → `['mean', 'median']` |
| `Enum` | Enumクラス | 0.85 | `Color.RED` → `[Color.RED, Color.BLUE]` |
| `bool` | bool型 | 0.80 | `bool` → `[True, False]` |
| `doc_summary` | Docstring解析 | 0.35 | "one of {a, b}" → `['a', 'b']` |
| `global_defaults` | 全体統計 | 0.55 | `n_jobs` → `[-1, 1, None]` |

**FR-3.2 値候補テーブル**
- **表示列**:
  - `Value`: 候補値
  - `Source`: 生成ソース
  - `Confidence`: 確度（0.0～1.0）
  - `Description`: 補足説明
- **ソート**: 確度降順
- **フィルタ**: 確度閾値（デフォルト: 0.3以上）

**FR-3.3 Docstring解析（簡易版）**
- 正規表現パターン:
  - `one of {a, b, c}`
  - `{a|b|c}`
  - `a, b, or c`
- 抽出値の検証:
  - 型との整合性チェック
  - 長さ制限（100文字以内）

### 3.4 Navigation & Exploration (ナビゲーション)

**FR-4.1 5階層ナビゲーション（ミラー・カラム）**

```
┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│ Modules  │→│  Items   │→│ Members  │→│  Params  │→│  Values  │
│          │  │          │  │          │  │          │  │          │
│ chronos  │  │ class    │  │ method   │  │ forecast │  │ 'mean'   │
│ ├─model  │  │ function │  │ property │  │ horizon  │  │ 'median' │
│ ├─utils  │  │ external │  │          │  │ verbose  │  │ True     │
│ └─config │  │          │  │          │  │          │  │ False    │
└──────────┘  └──────────┘  └──────────┘  └──────────┘  └──────────┘
     ↓              ↓              ↓              ↓              ↓
   選択時        選択時          選択時          選択時        選択可
  次列更新      次列更新        次列更新        次列更新      （複数）
```

**FR-4.2 カスケード制御（選択ミス防止）**
- **ルール**:
  1. 上流（左側）選択変更時、下流（右側）の選択値をクリア
  2. 下流の選択肢を上流選択に基づいて動的生成
  3. 無効な選択肢は表示しない
- **実装**:
  - `on_change` イベントで連鎖更新
  - `disabled` 状態の制御

**FR-4.3 検索・フィルタ機能**
- **検索対象**:
  - Name（名前）
  - Docstring（説明文）
  - Signature（シグネチャ）
  - Type（種別）
- **フィルタ条件**:
  - Kind（module/class/function/method/property）
  - Public/Private（`_` で始まるか）
  - 引数数（0, 1-3, 4-10, 10+）
  - 型ヒント有無
- **ソート**:
  - 名前（昇順/降順）
  - 行数（LOC）
  - 引数数

**FR-4.4 ブックマーク機能**
- 興味のあるAPIをバスケットに追加
- バスケット内での比較表示
- バスケット保存・復元（JSON）

### 3.5 Inspector (詳細表示)

**FR-5.1 基本情報**
- **表示項目**:
  - 完全修飾名（FQN）
  - 種別（Kind）
  - 定義ファイルパス
  - 行番号範囲
  - ソースコード（折りたたみ可）

**FR-5.2 Docstring表示**
- Markdown形式でレンダリング
- セクション別表示:
  - 概要（Summary）
  - パラメータ（Parameters）
  - 返り値（Returns）
  - 例（Examples）
- 長文の場合は折りたたみ

**FR-5.3 シグネチャ表示**
- シンタックスハイライト
- 型ヒント強調表示
- デフォルト値の視覚化

**FR-5.4 引数テーブル**

| 引数名 | データ型 | デフォルト値 | 種別 | 必須 | 説明 |
|--------|---------|-------------|------|------|------|
| forecast_horizon | int | 10 | POSITIONAL_OR_KEYWORD | ○ | 予測期間 |
| verbose | bool | False | KEYWORD_ONLY | × | 詳細出力 |

**FR-5.5 値候補テーブル（引数選択時）**
- 上記 FR-3.2 参照
- 値選択機能（複数選択可）
- 選択値をCodeGenに反映

**FR-5.6 関連API表示**
- 同じモジュール内のAPI
- 類似シグネチャのAPI（Similarityエンジン）
- 継承関係（親クラス・子クラス）
- 依存関係（使用している/されている）

### 3.6 Visualization (可視化)

**FR-6.1 Sunburst Chart（全体構造俯瞰）**
- **階層パス**: `Library → Module → Type → Name`
- **インタラクティブ**:
  - クリックでドリルダウン
  - ホバーで詳細ツールチップ
- **色分け**:
  - Type別（module: 青、class: 緑、function: 橙、method: 紫）
- **サイズ**: LOC（行数）またはメンバー数

**FR-6.2 Mermaid Diagram（関係図）**

**FR-6.2.1 Mermaidコード生成**
- **クラス図（Class Diagram）**:
  - 継承関係（`<|--`）
  - 集約・コンポジション
  - メンバー一覧
- **フローチャート（Flowchart）**:
  - モジュール依存関係
  - API呼び出しフロー
- **シーケンス図（Sequence）**（Phase 7拡張）:
  - メソッド呼び出し順序

**FR-6.2.2 Mermaid描画（UI内）**
- **ライブラリ使用**: Mermaid.js (CDN)
- **レンダリング方法**:
  ```html
  <div class="mermaid">
  {mermaid_code}
  </div>
  ```
- **インタラクティブ機能**:
  - ズーム・パン
  - ノードクリックで詳細表示

**FR-6.2.3 HTML出力**
- **形式**: 単体で開けるHTMLファイル
- **内容**:
  - Mermaid.js（CDN参照 or 同梱）
  - スタイルシート
  - 図コード
- **出力先**: `outputs/v5/{library}/diagram.html`
- **追加機能**（オプション）:
  - SVG/PNG書き出し（CLIまたはヘッドレスブラウザ）

**FR-6.3 PyVis Network Graph（類似度グラフ）**
- **ノード**: API（class/function/method）
- **エッジ**: 類似度（閾値以上のみ）
- **レイアウト**: Force-directed
- **インタラクティブ**:
  - ノードドラッグ
  - ホバーでラベル表示
  - クリックで詳細表示
- **注意事項**:
  - ノード数上限（デフォルト: 500）
  - 自動再計算OFF（パフォーマンス対策）

### 3.7 Code Generation (コード生成)

**FR-7.1 サンプル実行コード生成**

**対象**:
- 選択中の class / function / method / property

**出力構成**:
1. **Import文**:
   ```python
   from {module} import {item}
   ```
   必要最小限のimportのみ

2. **インスタンス化**（クラスの場合）:
   ```python
   instance = ClassName(param1=value1, param2=value2)
   ```
   - デフォルト値がある引数は省略
   - UI選択値を反映

3. **メソッド呼び出し**:
   ```python
   result = instance.method(arg1=val1, arg2=val2)
   print(result)
   ```

4. **サンプルデータ生成**（必要な場合）:
   ```python
   # Sample data generation
   import pandas as pd
   df = pd.DataFrame({
       'date': pd.date_range('2024-01-01', periods=100),
       'value': np.random.randn(100)
   })
   ```

**FR-7.2 サンプルデータ生成エンジン**

**型別生成ルール**:

| 型 | 生成方法 | 例 |
|----|---------|-----|
| `pd.DataFrame` | 列名推定＋ランダムデータ | `pd.DataFrame({'A': [1,2,3]})` |
| `np.ndarray` | shape推定＋ランダム値 | `np.random.randn(10, 5)` |
| `str` / `Path` | 一時ファイル作成 | `tempfile.mktemp(suffix='.csv')` |
| `bool` | `True` または `False` | `True` |
| `int` | 典型的な値 | `10`, `100`, `1000` |
| `float` | 典型的な値 | `0.5`, `1.0`, `0.01` |
| `list` / `dict` | 空または小サンプル | `[]`, `{}`, `[1,2,3]` |

**FR-7.3 コピー・実行機能**
- **コピーボタン**: クリップボードにコピー
- **実行ボタン**（オプション）:
  - Notebookセルに挿入
  - 実行＋結果表示
  - エラーハンドリング

**FR-7.4 コード最適化**
- 不要なコメント削除
- PEP 8準拠のフォーマット（black使用）
- import整理（isort使用）

### 3.8 Similarity & Clustering (類似度・クラスタリング)

**FR-8.1 特徴量生成**
- **Name**: 単語分割（snake_case, camelCase）
- **Signature**: 引数名・型の集合
- **Docstring**: TF-IDF ベクトル
- **Type**: one-hot エンコーディング
- **重み付け**: 各特徴量の重要度を設定可能

**FR-8.2 類似度計算**
- **手法**: Cosine類似度
- **閾値**: デフォルト 0.3（UI調整可）
- **Top-K**: 上位K件を表示（デフォルト: 10）
- **根拠表示**:
  - 効いた特徴語（上位5語）
  - 一致要素（引数名、型など）
  - スコア分解

**FR-8.3 クラスタリング**
- **手法**: 
  - KMeans（デフォルト）
  - 階層的クラスタリング（オプション）
- **クラスタ数決定**:
  - エルボー法
  - シルエット係数
  - ユーザー指定
- **代表API抽出**:
  - クラスタ中心に最も近いAPI
- **代表語抽出**:
  - TF-IDF上位語（クラスタ内）

**FR-8.4 ラベリング機能**
- クラスタに手動でラベル付与
- ラベル保存（YAML）
- ラベルベースのフィルタ・検索

### 3.9 Export & Reporting (エクスポート・レポート)

**FR-9.1 エクスポート形式**

| 形式 | 内容 | 用途 |
|------|------|------|
| **CSV** | APIテーブル | Excelでの分析・フィルタ |
| **JSON** | 階層構造データ | プログラム的な利用 |
| **Excel** | 複数シート（API/引数/値候補/統計） | 総合レポート |
| **HTML** | インタラクティブレポート | プレゼン・共有 |
| **Markdown** | ドキュメント | ドキュメント生成 |
| **pickle** | Python オブジェクト | キャッシュ・復元 |

**FR-9.2 HTMLレポート構成**
- **目次**:
  - 統計サマリー
  - API一覧
  - クラス図
  - サンプルコード集
- **インタラクティブ機能**:
  - フィルタ・検索
  - ソート
  - ツリービュー
- **スタイル**: Bootstrap 5

**FR-9.3 スナップショット管理**
- **snapshot_id**: `{library}_{version}_{timestamp}`
- **保存内容**:
  - 解析結果（JSON）
  - 設定（YAML）
  - ログ（TXT）
- **復元機能**:
  - snapshot_id指定で即座に再現
  - 再解析不要

---

## 4. 非機能要件

### 4.1 パフォーマンス

| 項目 | 要件 | 計測方法 |
|------|------|---------|
| **解析速度** | 1000モジュール / 5分以内 | タイマー計測 |
| **UI応答性** | ユーザー操作後1秒以内に反応 | UXテスト |
| **メモリ使用量** | 最大2GB（大規模ライブラリ） | memory_profiler |
| **キャッシュ効果** | 2回目以降の起動は5秒以内 | ベンチマーク |

### 4.2 信頼性

| 項目 | 要件 | 対策 |
|------|------|------|
| **部分失敗許容** | 1モジュール失敗でも処理継続 | try-except + errorsテーブル |
| **データ整合性** | 親子関係の不整合を許さない | parent_id検証 |
| **エラーリカバリ** | 自動再試行（最大3回） | デコレータ実装 |
| **ログ保存** | 全エラーをログファイルに記録 | logging モジュール |

### 4.3 保守性

| 項目 | 要件 | 実装 |
|------|------|------|
| **バージョン管理** | V4と共存可能 | 別ディレクトリ（v5/） |
| **設定外部化** | ハードコード禁止 | YAML設定ファイル |
| **プラグイン機構** | 値候補生成ルールを追加可能 | インターフェース定義 |
| **ドキュメント** | Docstring 100%、使用例あり | Sphinx生成 |

### 4.4 ユーザビリティ

| 項目 | 要件 |
|------|------|
| **学習時間** | 初見で30分以内に基本操作習得 |
| **ヘルプ** | 各機能にツールチップ・ヘルプボタン |
| **エラーメッセージ** | ユーザーが理解できる日本語メッセージ |
| **フィードバック** | 長時間処理には進捗バー表示 |

### 4.5 拡張性

| 項目 | 要件 |
|------|------|
| **多言語対応** | UIテキストを外部化（i18n） |
| **テーマ切替** | ライト/ダークモード対応 |
| **API公開** | 他ツールから利用可能なAPI提供 |
| **プラグイン** | カスタムアナライザー追加可能 |

---

## 5. データモデル

### 5.1 コアモデル

**Node (API要素)**
```python
@dataclass
class Node:
    # 識別
    id: str                          # 一意ID（通常はFQN）
    kind: str                        # module/class/function/method/property/external
    name: str                        # 短縮名
    fqn: str                         # 完全修飾名（表示用）
    parent_id: Optional[str]         # 親ノードID
    
    # 定義元
    origin_module: Optional[str]     # 定義モジュール名
    origin_file: Optional[str]       # 定義ファイルパス
    lineno: Optional[int]            # 開始行
    end_lineno: Optional[int]        # 終了行
    
    # シグネチャ情報
    signature: str                   # inspect.signature() の文字列表現
    param_names: List[str]           # 引数名リスト
    param_types: Dict[str, str]      # 引数名 → 型ヒント
    param_defaults: Dict[str, Any]   # 引数名 → デフォルト値
    param_kinds: Dict[str, str]      # 引数名 → 種別（POSITIONAL_ONLY等）
    return_type: Optional[str]       # 返り値型
    
    # メタデータ
    doc_summary: str                 # Docstring（最初の120文字）
    doc_full: str                    # Docstring（全文）
    loc: int                         # 行数（Lines of Code）
    
    # フラグ
    flags: Dict[str, Any]            # 拡張用（is_async, is_property, events等）
```

**ParamValueHints (引数値候補)**
```python
@dataclass
class ParamValueCandidate:
    value: Any                       # 候補値
    source: str                      # default/literal/enum/bool/doc/global
    confidence: float                # 確度（0.0～1.0）
    description: str                 # 補足説明

@dataclass
class ParamValueHints:
    param_name: str                  # 引数名
    param_type: Optional[str]        # 型
    candidates: List[ParamValueCandidate]  # 候補リスト
```

**AnalysisConfig (解析設定)**
```python
@dataclass
class AnalysisConfig:
    # スコープ
    max_modules: int = 5000
    max_depth: int = 20
    
    # フィルタ
    include_private: bool = False
    include_external_reexports: bool = False
    include_inherited_members: bool = False
    
    # 実行戦略
    dynamic_import: bool = True
    ast_parse: bool = True
    
    # パフォーマンス
    cache_enabled: bool = True
    parallel: bool = False
    num_workers: int = 4
```

**AnalysisResult (解析結果)**
```python
@dataclass
class AnalysisResult:
    lib_name: str
    lib_version: str
    snapshot_id: str
    
    nodes: List[Node]
    value_hints: Dict[str, ParamValueHints]  # FQN → 値候補
    global_defaults: Dict[str, List[Any]]     # 引数名 → 頻出デフォルト値
    
    errors: List[str]
    warnings: List[str]
    stats: Dict[str, Any]            # 統計情報
    
    timestamp: datetime
```

### 5.2 台帳モデル（pip list系）

**PackageInventory**
```python
@dataclass
class PackageInfo:
    name: str
    version: str
    editable_path: Optional[str]
    is_editable: bool
    location: str                    # site-packages パス
    metadata: Dict[str, Any]         # 追加メタデータ

@dataclass
class PackageInventory:
    packages: List[PackageInfo]
    source: str                      # file/paste
    timestamp: datetime
    errors: List[str]
```

### 5.3 類似度・クラスタモデル

**SimilarityEdge**
```python
@dataclass
class SimilarityEdge:
    source_id: str
    target_id: str
    score: float
    evidence: Dict[str, Any]         # 根拠（特徴語、一致要素等）
```

**Cluster**
```python
@dataclass
class Cluster:
    cluster_id: int
    label: str                       # ユーザー定義ラベル
    member_ids: List[str]            # クラスタメンバーのID
    representative_id: str           # 代表API
    keywords: List[str]              # 代表語（上位5語）
    size: int
```

---

## 6. UI/UX要件

### 6.1 タブ構成

```
┌─────────────────────────────────────────────────────────────┐
│  Library Explorer V5                          [Settings] [?] │
├─────────────────────────────────────────────────────────────┤
│ [Dashboard] [Explorer] [Inspector] [Graph] [Mermaid]        │
│ [CodeGen] [Similarity] [Cluster] [Export]                   │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  {タブごとの内容}                                            │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

**各タブの詳細**:

1. **Dashboard（統計ダッシュボード）**
   - ライブラリ選択・読み込み
   - 統計カード（モジュール数、クラス数、関数数等）
   - 最近の解析履歴
   - クイックアクション

2. **Explorer（5階層ナビゲーション）**
   - Modules → Items → Members → Params → Values
   - 検索バー・フィルタ
   - ソート機能
   - ブックマーク

3. **Inspector（詳細表示）**
   - 基本情報（FQN、Kind、位置）
   - Docstring（Markdown）
   - シグネチャ（ハイライト）
   - 引数テーブル
   - 値候補テーブル
   - 関連API

4. **Graph（PyVisネットワーク）**
   - ノード・エッジ表示
   - レイアウト選択
   - フィルタ（Type、類似度閾値）
   - ノードクリックで詳細

5. **Mermaid（図表）**
   - Mermaidコード表示
   - 図のレンダリング
   - HTML出力ボタン
   - SVG/PNG出力（オプション）

6. **CodeGen（コード生成）**
   - 選択API情報
   - 値選択UI
   - 生成コードプレビュー
   - コピー・実行ボタン
   - サンプルデータプレビュー

7. **Similarity（類似API推薦）**
   - 基準API選択
   - Top-K設定
   - 類似リスト（スコア付き）
   - 根拠表示
   - Compare へ送る

8. **Cluster（クラスタリング）**
   - クラスタ数設定
   - クラスタ一覧（代表API、サイズ）
   - ラベル編集
   - クラスタ内API一覧
   - クラスタ間遷移

9. **Export（エクスポート）**
   - 形式選択（CSV, JSON, Excel, HTML）
   - フィルタ適用
   - ダウンロードボタン
   - エクスポート履歴

### 6.2 デザインシステム

**カラーパレット**:
```
Primary:   #2196F3 (青)
Secondary: #4CAF50 (緑)
Accent:    #FF9800 (橙)
Error:     #F44336 (赤)
Warning:   #FFC107 (黄)
Info:      #00BCD4 (シアン)
Success:   #8BC34A (薄緑)

Background:     #FAFAFA (薄灰)
Surface:        #FFFFFF (白)
Text Primary:   #212121 (濃灰)
Text Secondary: #757575 (中灰)
Border:         #E0E0E0 (薄灰)
```

**タイポグラフィ**:
- **見出し**: Roboto, sans-serif
- **本文**: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif
- **コード**: 'Consolas', 'Monaco', 'Courier New', monospace

**コンポーネント**:
- **ボタン**: 角丸4px、ホバーで明度変更
- **カード**: 影付き、padding 16px
- **テーブル**: ストライプ、ホバーハイライト
- **フォーム**: ラベル上配置、フォーカス時青枠

**レスポンシブ**:
- デスクトップ優先（Notebookでの利用前提）
- タブレット対応（1024px以上）
- モバイル対応は Phase 7 拡張

### 6.3 アクセシビリティ

- **キーボード操作**: 全機能をキーボードで操作可能
- **スクリーンリーダー**: ARIA属性の適切な使用
- **色覚対応**: 色だけに依存しない情報伝達
- **コントラスト**: WCAG AA基準（4.5:1以上）

---

## 7. 実装計画

### 7.1 フェーズ分け（Phase 0～7）

**Phase 0: 土台構築**（1週間）
- プロジェクト構造作成
- 設定管理（config.py, settings.json）
- ログ基盤（logging_util.py）
- キャッシュ基盤（cache_store.py）

**Phase 1: Import & Inventory**（1週間）
- pip list読み込み（io_piplist.py）
- 正規化・パース
- 台帳生成
- CSV/Excel出力

**Phase 2: AST解析（安全コア）**（2週間）
- モジュール探索（pkgutil）
- AST抽出（extract_ast.py）
- parent_id管理
- エラーハンドリング
- ノード生成

**Phase 3: UI基盤（探索ループ成立）**（2週間）
- Dashboard タブ
- Explorer タブ（5階層ナビ）
- Inspector タブ（基本表示）
- Search/Filter機能
- 統合テスト

**Phase 4: Runtime解析 & 値候補生成**（2週間）
- Runtime抽出（extract_runtime.py）
- シグネチャ・デフォルト値取得
- 値候補生成エンジン
- global_defaults 集計
- Inspector 引数テーブル・値候補テーブル

**Phase 5: Mermaid強化**（1週間）
- Mermaidコード生成（既存資産活用）
- UI内レンダリング（mermaid_render_v5.py）
- HTML出力（mermaid_export_v5.py）
- Mermaid タブ統合

**Phase 6: CodeGen（サンプル実行コード生成）**（2週間）
- CodeGenエンジン（codegen_v5.py）
- サンプルデータ生成（sample_data_factory_v5.py）
- CodeGen タブUI
- コピー・実行機能

**Phase 7: 類似度・クラスタリング（洞察増幅）**（2週間）
- 特徴量生成（features.py）
- 類似度計算（similarity.py）
- クラスタリング（cluster.py）
- Similarity/Cluster タブ
- Graph タブ（PyVis）

**Phase 8: Export & 運用強化**（1週間）
- Export タブ
- HTMLレポート生成
- スナップショット管理
- api_overrides.yml
- プラグイン拡張点

**Phase 9: 品質強化（テスト・ドキュメント）**（2週間）
- 単体テスト（pytest）
- 結合テスト
- 性能テスト（profiling）
- ドキュメント整備（Sphinx）
- 回帰テスト

### 7.2 WBS（作業分解構造）

| ID | タスク | 依存 | 成果物 | 工数 | 完了条件 |
|----|--------|------|--------|------|---------|
| P0-01 | ディレクトリ構造作成 | - | フォルダ一式 | 0.5d | ツリー構造確認 |
| P0-02 | config.py 実装 | P0-01 | config.py | 1d | 設定読み込みOK |
| P0-03 | logging_util.py 実装 | P0-01 | logging_util.py | 1d | ログ出力確認 |
| P0-04 | cache_store.py 実装 | P0-01 | cache_store.py | 1d | 保存・復元OK |
| P1-01 | io_piplist.py 実装 | P0-02 | io_piplist.py | 2d | pip list パースOK |
| P1-02 | 台帳Export実装 | P1-01 | exporters.py | 1d | CSV/Excel出力 |
| P2-01 | extract_ast.py 実装 | P0-02 | extract_ast.py | 3d | AST抽出OK |
| P2-02 | models_v5.py 実装 | - | models_v5.py | 2d | Nodeモデル完成 |
| P2-03 | analyzer_v5.py（AST部分） | P2-01, P2-02 | analyzer_v5.py | 3d | 解析結果生成 |
| P3-01 | ui_v5.py（Dashboard） | P2-03 | ui_v5.py | 2d | 統計表示OK |
| P3-02 | ui_v5.py（Explorer 5階層） | P3-01 | ui_v5.py | 4d | カスケード動作 |
| P3-03 | ui_v5.py（Inspector基本） | P3-02 | ui_v5.py | 2d | 詳細表示OK |
| P3-04 | Search/Filter実装 | P3-02 | ui_v5.py | 2d | 検索・絞り込みOK |
| P4-01 | extract_runtime.py 実装 | P2-03 | extract_runtime.py | 3d | Runtime抽出OK |
| P4-02 | 値候補生成エンジン | P4-01 | analyzer_v5.py | 3d | 候補生成OK |
| P4-03 | Inspector引数・値候補表 | P4-02 | ui_v5.py | 2d | テーブル表示OK |
| P5-01 | mermaid_render_v5.py | - | mermaid_render_v5.py | 2d | UI描画OK |
| P5-02 | mermaid_export_v5.py | P5-01 | mermaid_export_v5.py | 1d | HTML出力OK |
| P5-03 | Mermaidタブ統合 | P5-02 | ui_v5.py | 1d | タブ動作OK |
| P6-01 | codegen_v5.py 実装 | P4-02 | codegen_v5.py | 3d | コード生成OK |
| P6-02 | sample_data_factory_v5.py | - | sample_data_factory_v5.py | 2d | データ生成OK |
| P6-03 | CodeGenタブ統合 | P6-01, P6-02 | ui_v5.py | 2d | タブ動作OK |
| P7-01 | features.py 実装 | P2-03 | features.py | 2d | 特徴量生成OK |
| P7-02 | similarity.py 実装 | P7-01 | similarity.py | 2d | 類似度計算OK |
| P7-03 | cluster.py 実装 | P7-01 | cluster.py | 2d | クラスタリングOK |
| P7-04 | Similarity/Clusterタブ | P7-02, P7-03 | ui_v5.py | 2d | タブ動作OK |
| P7-05 | Graphタブ（PyVis） | P7-02 | ui_v5.py | 2d | グラフ表示OK |
| P8-01 | Exportタブ実装 | P3-03 | ui_v5.py | 2d | エクスポートOK |
| P8-02 | HTMLレポート生成 | P8-01 | exporters.py | 2d | レポートOK |
| P8-03 | api_overrides.yml実装 | P2-03 | api_overrides.yml | 1d | オーバーライドOK |
| P9-01 | 単体テスト作成 | 全Phase | tests/ | 3d | カバレッジ80%+ |
| P9-02 | 結合テスト作成 | P9-01 | tests/ | 2d | E2Eシナリオ通過 |
| P9-03 | ドキュメント整備 | 全Phase | docs/ | 3d | Sphinx生成OK |

**総工数**: 約 70日（14週間）

### 7.3 マイルストーン

| MS | 名称 | 完了条件 | 期限 |
|----|------|---------|------|
| M0 | 土台完成 | P0全完了 | Week 1 |
| M1 | 台帳管理OK | P1全完了 | Week 2 |
| M2 | AST解析OK | P2全完了 | Week 4 |
| M3 | 探索ループ成立 | P3全完了 | Week 6 |
| M4 | 値候補生成OK | P4全完了 | Week 8 |
| M5 | Mermaid完成 | P5全完了 | Week 9 |
| M6 | CodeGen完成 | P6全完了 | Week 11 |
| M7 | 類似・クラスタOK | P7全完了 | Week 13 |
| M8 | Export完成 | P8全完了 | Week 14 |
| M9 | 品質保証完了 | P9全完了 | Week 16 |

---

## 8. テスト戦略

### 8.1 単体テスト（Unit Test）

**対象**:
- 各モジュールの関数・メソッド
- データモデルのバリデーション
- ユーティリティ関数

**フレームワーク**: pytest

**カバレッジ目標**: 80%以上

**テストケース例**:
```python
def test_parse_pip_list():
    input_text = """
    Package    Version
    ---------- -------
    pandas     2.0.0
    numpy      1.24.0
    """
    result = parse_pip_list(input_text)
    assert len(result) == 2
    assert result[0].name == 'pandas'
    assert result[0].version == '2.0.0'

def test_extract_ast():
    code = """
    class MyClass:
        def my_method(self, arg1: int = 10):
            pass
    """
    nodes = extract_ast_from_string(code)
    assert len(nodes) == 2  # MyClass, my_method
    assert nodes[0].kind == 'class'
    assert nodes[1].kind == 'method'
    assert nodes[1].param_defaults['arg1'] == 10
```

### 8.2 結合テスト（Integration Test）

**対象**:
- モジュール間の連携
- UI → Analyzer → Data の一連の流れ
- Export機能

**シナリオ例**:
1. pip list 読み込み → 台帳生成 → CSV出力
2. ライブラリ選択 → AST解析 → ノード生成 → UI表示
3. API選択 → 値候補生成 → コード生成 → コピー

### 8.3 E2Eテスト（End-to-End Test）

**シナリオ**:
1. **新規ライブラリ解析**:
   - Dashboardでライブラリ選択
   - 解析実行
   - Explorerで探索
   - InspectorでAPI詳細確認
   - CodeGen でコード生成
   - Exportで結果保存

2. **既存解析の再利用**:
   - スナップショット選択
   - 即座に復元
   - 検索・フィルタ
   - 追加分析（類似度）

### 8.4 性能テスト（Performance Test）

**計測項目**:
- 解析時間（モジュール数別）
- メモリ使用量
- UI応答時間
- キャッシュヒット率

**ベンチマーク**:
```python
def benchmark_analysis():
    libraries = ['pandas', 'numpy', 'scikit-learn', 'torch']
    for lib in libraries:
        start = time.time()
        analyzer = LibraryAnalyzerV5(lib)
        result = analyzer.analyze()
        elapsed = time.time() - start
        print(f"{lib}: {elapsed:.2f}s, {len(result.nodes)} nodes")
```

### 8.5 ユーザビリティテスト

**参加者**: 5名（初心者3名、中級者2名）

**タスク**:
1. 新しいライブラリ（例: `plotly`）を解析
2. 特定のクラス（例: `Figure`）を見つける
3. メソッド（例: `add_trace`）の引数を確認
4. サンプルコードを生成して実行

**評価指標**:
- タスク完了率
- 完了時間
- 満足度（5段階）
- 改善提案

---

## 9. リスクと対策

### 9.1 技術リスク

| リスク | 発生確率 | 影響度 | 対策 |
|--------|---------|--------|------|
| **import副作用による環境破壊** | 中 | 高 | デフォルトAST、Runtime明示ON、ブラックリスト |
| **巨大ライブラリでのメモリ不足** | 高 | 中 | ストリーミング解析、max_modules制限 |
| **外部ライブラリ依存の脆弱性** | 低 | 中 | 最小依存、定期アップデート |
| **ipywidgets動作環境の制約** | 中 | 中 | HTML/JSフォールバック実装 |

### 9.2 データ品質リスク

| リスク | 発生確率 | 影響度 | 対策 |
|--------|---------|--------|------|
| **継承メソッドの混入** | 高 | 中 | `__dict__` ベースの抽出（デフォルト） |
| **外部再エクスポートの混入** | 高 | 中 | `__module__` チェック、除外機能 |
| **値候補の誤推定** | 中 | 低 | 確度表示、ソース明示、手動調整可能 |
| **階層構造の不整合** | 低 | 高 | parent_id検証、テストで担保 |

### 9.3 スケジュールリスク

| リスク | 発生確率 | 影響度 | 対策 |
|--------|---------|--------|------|
| **想定外のバグ発生** | 高 | 中 | 週次レビュー、早期テスト |
| **新規要件の追加** | 中 | 中 | Phase 7以降に集約、優先順位明確化 |
| **メンバー不在** | 低 | 高 | ドキュメント充実、ペアプログラミング |

### 9.4 運用リスク

| リスク | 発生確率 | 影響度 | 対策 |
|--------|---------|--------|------|
| **Pythonバージョン非互換** | 中 | 中 | 3.9～3.12 対応明記、CI/CDテスト |
| **ライブラリアップデートで動作不良** | 中 | 低 | 依存バージョン固定、定期テスト |
| **キャッシュ肥大化** | 中 | 低 | 定期クリーンアップ、サイズ上限 |

---

## 10. 付録

### 10.1 用語集

| 用語 | 説明 |
|------|------|
| **FQN** | Fully Qualified Name（完全修飾名）。例: `pandas.DataFrame.describe` |
| **AST** | Abstract Syntax Tree（抽象構文木）。Pythonコードを構文解析した木構造 |
| **Runtime解析** | import して inspect モジュールで実行時情報を取得する解析手法 |
| **継承メソッド** | 親クラスから継承したメソッド（自クラスで定義していない） |
| **外部再エクスポート** | 他モジュールで定義されたものを自モジュールで公開すること |
| **値候補** | 引数に渡す可能性のある値のリスト（型・デフォルト・ドキュメント等から推定） |
| **確度** | 値候補の信頼度（0.0～1.0）。生成ソースによって異なる |
| **TF-IDF** | Term Frequency-Inverse Document Frequency。文書中の単語の重要度を測る指標 |
| **Cosine類似度** | ベクトル間の角度で類似度を測る手法 |
| **KMeans** | k平均法。クラスタリングアルゴリズムの一種 |

### 10.2 参考資料

- [Python inspect モジュール公式ドキュメント](https://docs.python.org/3/library/inspect.html)
- [AST モジュール公式ドキュメント](https://docs.python.org/3/library/ast.html)
- [ipywidgets公式ドキュメント](https://ipywidgets.readthedocs.io/)
- [Mermaid公式ドキュメント](https://mermaid.js.org/)
- [PyVis公式ドキュメント](https://pyvis.readthedocs.io/)

### 10.3 設定ファイル例

**configs/settings.json**
```json
{
  "analysis": {
    "max_modules": 5000,
    "max_depth": 20,
    "include_private": false,
    "include_external_reexports": false,
    "include_inherited_members": false,
    "dynamic_import": true,
    "ast_parse": true
  },
  "ui": {
    "theme": "light",
    "default_tab": "Dashboard",
    "rows_per_page": 50
  },
  "export": {
    "default_format": "csv",
    "output_dir": "outputs/exports"
  },
  "cache": {
    "enabled": true,
    "dir": "cache",
    "max_size_mb": 1000
  }
}
```

**configs/api_overrides.yml**
```yaml
# 特定ライブラリの公開API面をカスタマイズ
overrides:
  pandas:
    exclude_modules:
      - pandas.core.internals
      - pandas._libs
    include_only:
      - pandas.DataFrame
      - pandas.Series
      - pandas.read_csv
      - pandas.read_excel
  
  scikit-learn:
    exclude_patterns:
      - ".*\\_.*"  # private
      - ".*test.*"  # test utilities
```

### 10.4 起動コード例

**lib.ipynb セル**
```python
# V5 起動コード
import sys
sys.path.insert(0, r'C:\lib_ana\src')

from v5.ui_v5 import CognitiveLibraryUIV5

# UIインスタンス生成・表示
ui = CognitiveLibraryUIV5()
ui.display()
```

**pip list解析系の起動**
```python
# pip list解析系 起動コード
import sys
sys.path.insert(0, r'C:\lib_ana\src')

from lib_ana.io_piplist import load_pip_list
from lib_ana.ui_widgets import InventoryUI

# pip list読み込み
inventory = load_pip_list('data/pip_list.txt')

# UI表示
ui = InventoryUI(inventory)
ui.display()
```

---

## 11. 承認・変更履歴

| バージョン | 日付 | 変更内容 | 承認者 |
|-----------|------|---------|--------|
| 1.0 | 2026-02-05 | 初版作成 | - |

---

**以上、Python ライブラリ解析システム V5 統合要件定義書**
