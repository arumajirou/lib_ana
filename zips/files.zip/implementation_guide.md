# Python ライブラリ解析システム V5 実装ガイド

**対象読者**: 開発者  
**目的**: 実装時の具体的な指針とベストプラクティスを提供

---

## 目次

1. [開発環境セットアップ](#1-開発環境セットアップ)
2. [コーディング規約](#2-コーディング規約)
3. [モジュール別実装ガイド](#3-モジュール別実装ガイド)
4. [テスト実装ガイド](#4-テスト実装ガイド)
5. [デバッグ・トラブルシューティング](#5-デバッグトラブルシューティング)
6. [パフォーマンス最適化](#6-パフォーマンス最適化)

---

## 1. 開発環境セットアップ

### 1.1 前提条件

- Python 3.9 ～ 3.12
- Jupyter Notebook または JupyterLab
- Git

### 1.2 依存ライブラリインストール

```bash
# 基本依存
pip install pandas numpy
pip install ipywidgets plotly pyvis
pip install pyyaml

# 解析系
pip install libcst  # オプション（詳細AST解析）

# 類似度・クラスタリング
pip install scikit-learn

# コード整形
pip install black isort

# テスト
pip install pytest pytest-cov

# ドキュメント
pip install sphinx sphinx-rtd-theme
```

### 1.3 プロジェクト構造作成

```bash
# ディレクトリ作成
mkdir -p C:\lib_ana\src\v5
mkdir -p C:\lib_ana\src\lib_ana
mkdir -p C:\lib_ana\src\common
mkdir -p C:\lib_ana\configs
mkdir -p C:\lib_ana\data\sample
mkdir -p C:\lib_ana\cache
mkdir -p C:\lib_ana\outputs
mkdir -p C:\lib_ana\logs
mkdir -p C:\lib_ana\tests

# __init__.py 作成
touch C:\lib_ana\src\v5\__init__.py
touch C:\lib_ana\src\lib_ana\__init__.py
touch C:\lib_ana\src\common\__init__.py
```

### 1.4 Jupyter設定

**Notebook拡張機能**:
```bash
# ipywidgets 有効化
jupyter nbextension enable --py widgetsnbextension
jupyter labextension install @jupyter-widgets/jupyterlab-manager
```

**カーネル設定**:
```bash
# 仮想環境の場合
python -m ipykernel install --user --name=leas --display-name="LEAS Python 3.11"
```

---

## 2. コーディング規約

### 2.1 スタイルガイド

**基本**: PEP 8 準拠

**自動フォーマット**:
```bash
# blackでコード整形
black src/ tests/

# isortでimport整理
isort src/ tests/

# 実行前チェック
black --check src/
isort --check src/
```

**設定ファイル（pyproject.toml）**:
```toml
[tool.black]
line-length = 100
target-version = ['py39', 'py310', 'py311', 'py312']
include = '\.pyi?$'
extend-exclude = '''
/(
  # 除外ディレクトリ
  | .git
  | .venv
  | cache
)/
'''

[tool.isort]
profile = "black"
line_length = 100
```

### 2.2 命名規則

| 対象 | 規則 | 例 |
|------|------|-----|
| モジュール | snake_case | `analyzer_v5.py` |
| クラス | PascalCase | `LibraryAnalyzerV5` |
| 関数・メソッド | snake_case | `analyze_module()` |
| 変数 | snake_case | `node_list` |
| 定数 | UPPER_SNAKE_CASE | `MAX_DEPTH` |
| プライベート | 先頭アンダースコア | `_internal_method()` |
| 型変数 | PascalCase + 'T' | `NodeT` |

### 2.3 Docstring規約

**Google Style準拠**:

```python
def analyze_module(module_name: str, config: AnalysisConfig) -> List[Node]:
    """モジュールを解析してノードリストを返す.

    Args:
        module_name (str): 解析対象モジュール名（例: 'pandas'）
        config (AnalysisConfig): 解析設定

    Returns:
        List[Node]: 抽出されたノードのリスト

    Raises:
        ImportError: モジュールがインポートできない場合
        ValueError: 設定が不正な場合

    Example:
        >>> config = AnalysisConfig(max_depth=10)
        >>> nodes = analyze_module('pandas', config)
        >>> len(nodes)
        1234
    """
    pass
```

### 2.4 型ヒント

**必須**: 全ての関数・メソッドに型ヒント

```python
from typing import List, Dict, Optional, Any, Union
from dataclasses import dataclass

@dataclass
class Node:
    id: str
    kind: str
    name: str
    parent_id: Optional[str] = None
    flags: Dict[str, Any] = field(default_factory=dict)

def process_nodes(
    nodes: List[Node],
    filter_func: Optional[Callable[[Node], bool]] = None
) -> List[Node]:
    """ノードをフィルタリング"""
    if filter_func is None:
        return nodes
    return [n for n in nodes if filter_func(n)]
```

**型チェック**:
```bash
# mypy でチェック
mypy src/ --ignore-missing-imports
```

---

## 3. モジュール別実装ガイド

### 3.1 models_v5.py

**重要ポイント**:

1. **dataclassの活用**:
```python
from dataclasses import dataclass, field
from typing import Dict, Any

@dataclass(frozen=True)  # イミュータブル
class AnalysisConfig:
    max_modules: int = 5000
    max_depth: int = 20

@dataclass
class Node:
    id: str
    # ... 他のフィールド
    flags: Dict[str, Any] = field(default_factory=dict)  # デフォルト値
    
    def __post_init__(self):
        """初期化後の検証"""
        if not self.id:
            raise ValueError("id は必須です")
```

2. **バリデーション**:
```python
@dataclass
class AnalysisConfig:
    max_modules: int = 5000
    
    def __post_init__(self):
        if self.max_modules <= 0:
            raise ValueError("max_modules は正の整数である必要があります")
```

### 3.2 analyzer_v5.py

**重要ポイント**:

1. **エラーハンドリング**:
```python
def analyze_module(self, mod_name: str) -> List[Node]:
    """モジュール解析（エラーを記録して継続）"""
    nodes = []
    
    try:
        # AST解析
        ast_nodes = self.ast_analyzer.analyze(mod_name)
        nodes.extend(ast_nodes)
    except Exception as e:
        self.errors.append(f"[AST] {mod_name}: {e}")
        # 処理は継続
    
    try:
        # Runtime解析
        if self.cfg.dynamic_import:
            runtime_nodes = self.runtime_analyzer.analyze(mod_name)
            nodes.extend(runtime_nodes)
    except Exception as e:
        self.errors.append(f"[Runtime] {mod_name}: {e}")
    
    return nodes
```

2. **タイムアウト実装**:
```python
import signal
from contextlib import contextmanager

@contextmanager
def timeout(seconds: int):
    """タイムアウトコンテキストマネージャー"""
    def timeout_handler(signum, frame):
        raise TimeoutError(f"処理が {seconds} 秒でタイムアウトしました")
    
    # Windowsでは動作しない（Unixのみ）
    if hasattr(signal, 'SIGALRM'):
        old_handler = signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(seconds)
        try:
            yield
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)
    else:
        # Windows代替: threading.Timer
        import threading
        timer = threading.Timer(seconds, lambda: print("警告: タイムアウト"))
        timer.start()
        try:
            yield
        finally:
            timer.cancel()

# 使用例
try:
    with timeout(30):
        mod = importlib.import_module(mod_name)
except TimeoutError as e:
    self.errors.append(str(e))
```

3. **AST安全解析**:
```python
def _parse_ast(self, file_path: str) -> ast.Module:
    """ASTパース（エンコーディング自動判定）"""
    encodings = ['utf-8', 'latin-1', 'cp1252']
    
    for enc in encodings:
        try:
            src = Path(file_path).read_text(encoding=enc)
            return ast.parse(src)
        except (UnicodeDecodeError, SyntaxError):
            continue
    
    raise ValueError(f"ファイルをパースできません: {file_path}")
```

### 3.3 ui_v5.py

**重要ポイント**:

1. **カスケード更新の実装**:
```python
def on_module_selected(self, change):
    """モジュール選択時のカスケード処理"""
    if not change['new']:
        return
    
    module_id = change['new']
    
    # 下流クリア（重要！）
    self.items_select.value = None
    self.members_select.value = None
    self.params_select.value = None
    self.values_select.value = []
    
    # 次の階層を更新
    items = self._get_children(module_id, kind=['class', 'function'])
    self.items_select.options = [(n.name, n.id) for n in items]
```

2. **長時間処理の進捗表示**:
```python
def on_analyze_clicked(self, b):
    """解析ボタンクリック"""
    with self.output:
        clear_output()
        
        # 進捗バー作成
        progress = widgets.IntProgress(
            value=0,
            min=0,
            max=100,
            description='解析中:',
            bar_style='info'
        )
        display(progress)
        
        # 解析実行
        lib_name = self.txt_lib.value
        analyzer = LibraryAnalyzerV5(lib_name, self.get_config())
        
        # コールバックで進捗更新
        def update_progress(current, total):
            progress.value = int(current / total * 100)
        
        analyzer.on_progress = update_progress
        result = analyzer.analyze()
        
        progress.bar_style = 'success'
        progress.description = '完了:'
```

3. **UI応答性の維持**:
```python
# 重い処理は別スレッドで
import threading

def run_analysis_async(self):
    """非同期解析実行"""
    def worker():
        with self.output:
            try:
                result = self.analyzer.analyze()
                self.on_analysis_complete(result)
            except Exception as e:
                self.on_analysis_error(e)
    
    thread = threading.Thread(target=worker)
    thread.daemon = True
    thread.start()
```

### 3.4 codegen_v5.py

**重要ポイント**:

1. **安全なコード生成**:
```python
def generate_function_call(self, node: Node, selected_values: Dict) -> str:
    """関数呼び出しコード生成（インジェクション対策）"""
    args = []
    
    for param in node.param_names:
        if param in selected_values:
            value = selected_values[param]
            # repr() で安全に文字列化
            safe_value = repr(value)
            args.append(f"{param}={safe_value}")
    
    args_str = ", ".join(args)
    # f-string ではなく format() を使用（安全性）
    return "{name}({args})".format(name=node.name, args=args_str)
```

2. **Import文の最適化**:
```python
def _generate_import(self, node: Node) -> str:
    """必要最小限のImport生成"""
    module = node.origin_module
    item = node.name
    
    # 既にインポート済みかチェック
    if self._is_already_imported(module, item):
        return ""
    
    # from X import Y 形式（推奨）
    return f"from {module} import {item}"

def _optimize_imports(self, code: str) -> str:
    """Import文を整理（isort使用）"""
    from isort import code as isort_code
    return isort_code(code)
```

---

## 4. テスト実装ガイド

### 4.1 単体テスト

**ファイル構成**:
```
tests/
├── __init__.py
├── test_models.py
├── test_analyzer.py
├── test_codegen.py
├── test_similarity.py
└── fixtures/
    └── sample_library/
```

**テスト例**:
```python
# tests/test_analyzer.py
import pytest
from src.v5.analyzer_v5 import LibraryAnalyzerV5, AnalysisConfig

class TestLibraryAnalyzerV5:
    
    @pytest.fixture
    def config(self):
        """テスト用設定"""
        return AnalysisConfig(
            max_modules=100,
            max_depth=5,
            dynamic_import=False  # テストでは安全のためOFF
        )
    
    @pytest.fixture
    def analyzer(self, config):
        """アナライザーインスタンス"""
        return LibraryAnalyzerV5('collections', config)
    
    def test_discover_modules(self, analyzer):
        """モジュール探索のテスト"""
        modules = analyzer.discover_modules()
        
        assert 'collections' in modules
        assert len(modules) > 0
        assert all(isinstance(m, str) for m in modules)
    
    def test_analyze_builtin(self, analyzer):
        """組み込みライブラリ解析のテスト"""
        result = analyzer.analyze()
        
        assert result.lib_name == 'collections'
        assert len(result.nodes) > 0
        assert len(result.errors) == 0  # エラーなし
    
    def test_analyze_nonexistent(self, config):
        """存在しないライブラリのテスト"""
        analyzer = LibraryAnalyzerV5('nonexistent_library', config)
        
        result = analyzer.analyze()
        
        assert len(result.nodes) == 0
        assert len(result.errors) > 0  # エラーあり
```

### 4.2 統合テスト

```python
# tests/test_integration.py
def test_end_to_end_analysis():
    """E2Eテスト: 解析→UI表示→コード生成"""
    # 1. 解析
    analyzer = LibraryAnalyzerV5('json', AnalysisConfig())
    result = analyzer.analyze()
    
    # 2. ノード選択
    json_loads = next(n for n in result.nodes if n.name == 'loads')
    
    # 3. コード生成
    codegen = CodeGenerator(SampleDataFactory())
    code = codegen.generate(json_loads, {'s': '{"key": "value"}'})
    
    # 4. 生成コード実行
    exec_globals = {}
    exec(code, exec_globals)
    
    # 5. 結果検証
    assert 'result' in exec_globals
```

### 4.3 パフォーマンステスト

```python
# tests/test_performance.py
import time
import pytest

def test_large_library_performance():
    """大規模ライブラリの性能テスト"""
    config = AnalysisConfig(max_modules=1000)
    analyzer = LibraryAnalyzerV5('pandas', config)
    
    start = time.time()
    result = analyzer.analyze()
    elapsed = time.time() - start
    
    # 5分以内に完了すること
    assert elapsed < 300
    assert len(result.nodes) > 100

@pytest.mark.benchmark
def test_similarity_calculation_speed(benchmark):
    """類似度計算のベンチマーク"""
    nodes = generate_test_nodes(1000)
    engine = SimilarityEngine(FeatureExtractor())
    
    def run_similarity():
        engine.build_index(nodes)
        return engine.find_similar(nodes[0].id, top_k=10)
    
    result = benchmark(run_similarity)
    assert len(result) == 10
```

---

## 5. デバッグ・トラブルシューティング

### 5.1 ログ設定

```python
# src/common/logging_util.py
import logging
from pathlib import Path

def setup_logger(name: str, log_file: str, level=logging.INFO):
    """ロガーのセットアップ"""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # ファイルハンドラ
    fh = logging.FileHandler(log_file, encoding='utf-8')
    fh.setLevel(level)
    
    # コンソールハンドラ
    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    
    # フォーマッタ
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    
    logger.addHandler(fh)
    logger.addHandler(ch)
    
    return logger

# 使用例
logger = setup_logger('analyzer', 'logs/analyzer.log')
logger.info('解析開始: pandas')
logger.error('エラー: %s', error_message)
```

### 5.2 デバッグヘルパー

```python
def debug_node(node: Node):
    """ノード情報をデバッグ出力"""
    print(f"=== Node Debug ===")
    print(f"ID: {node.id}")
    print(f"Kind: {node.kind}")
    print(f"FQN: {node.fqn}")
    print(f"Parent: {node.parent_id}")
    print(f"Params: {node.param_names}")
    print(f"Defaults: {node.param_defaults}")
    print(f"Types: {node.param_types}")
    print("==================")

def validate_hierarchy(nodes: List[Node]) -> List[str]:
    """階層構造の整合性チェック"""
    errors = []
    node_ids = {n.id for n in nodes}
    
    for node in nodes:
        if node.parent_id and node.parent_id not in node_ids:
            errors.append(f"親ノードが見つかりません: {node.id} -> {node.parent_id}")
    
    return errors
```

### 5.3 よくあるエラーと対処法

| エラー | 原因 | 対処法 |
|--------|------|--------|
| `ModuleNotFoundError` | ライブラリ未インストール | `pip install {library}` |
| `UnicodeDecodeError` | ファイルエンコーディング | 複数エンコーディングで試行 |
| `RecursionError` | 循環参照 | 訪問済みチェック実装 |
| `MemoryError` | 大規模ライブラリ | max_modules削減、ストリーミング化 |
| `TimeoutError` | 重い処理 | タイムアウト値調整、並列化 |

---

## 6. パフォーマンス最適化

### 6.1 キャッシュ戦略

```python
# src/common/cache_store.py
import json
import pickle
from pathlib import Path
from functools import lru_cache
from typing import Any, Optional

class CacheStore:
    """キャッシュストア"""
    
    def __init__(self, cache_dir: str = 'cache'):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
    
    def get(self, key: str, format: str = 'json') -> Optional[Any]:
        """キャッシュから取得"""
        file_path = self.cache_dir / f"{key}.{format}"
        
        if not file_path.exists():
            return None
        
        try:
            if format == 'json':
                return json.loads(file_path.read_text())
            elif format == 'pickle':
                return pickle.loads(file_path.read_bytes())
        except Exception as e:
            print(f"キャッシュ読み込みエラー: {e}")
            return None
    
    def set(self, key: str, value: Any, format: str = 'json'):
        """キャッシュに保存"""
        file_path = self.cache_dir / f"{key}.{format}"
        
        try:
            if format == 'json':
                file_path.write_text(json.dumps(value, indent=2))
            elif format == 'pickle':
                file_path.write_bytes(pickle.dumps(value))
        except Exception as e:
            print(f"キャッシュ保存エラー: {e}")
    
    def clear_old_cache(self, days: int = 7):
        """古いキャッシュを削除"""
        import time
        threshold = time.time() - (days * 86400)
        
        for file in self.cache_dir.glob('*'):
            if file.stat().st_mtime < threshold:
                file.unlink()

# メモリキャッシュ（関数レベル）
@lru_cache(maxsize=128)
def expensive_calculation(param: str) -> Any:
    """重い計算（結果をメモリキャッシュ）"""
    pass
```

### 6.2 並列処理

```python
from concurrent.futures import ThreadPoolExecutor, as_completed

def analyze_modules_parallel(self, modules: List[str], max_workers: int = 4) -> List[Node]:
    """モジュールを並列解析"""
    nodes = []
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # 各モジュールを並列解析
        futures = {
            executor.submit(self._analyze_single_module, mod): mod
            for mod in modules
        }
        
        # 完了したものから結果を取得
        for future in as_completed(futures):
            mod = futures[future]
            try:
                result = future.result()
                nodes.extend(result)
            except Exception as e:
                self.errors.append(f"並列解析エラー: {mod}: {e}")
    
    return nodes
```

### 6.3 メモリ最適化

```python
def analyze_large_library_streaming(self, lib_name: str) -> Iterator[Node]:
    """ストリーミング解析（メモリ効率的）"""
    modules = self.discover_modules()
    
    for mod_name in modules:
        # 1モジュールずつ処理
        nodes = self._analyze_single_module(mod_name)
        
        for node in nodes:
            yield node  # ジェネレータで返す
        
        # 処理済みデータを解放
        del nodes

# 使用例
for node in analyzer.analyze_large_library_streaming('tensorflow'):
    process_node(node)
    # メモリに全ノードを保持しない
```

---

## 7. CI/CD設定

### 7.1 GitHub Actions

**.github/workflows/ci.yml**:
```yaml
name: CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.9', '3.10', '3.11', '3.12']
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v4
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install pytest pytest-cov black isort mypy
    
    - name: Lint with black
      run: black --check src/ tests/
    
    - name: Sort imports
      run: isort --check src/ tests/
    
    - name: Type check
      run: mypy src/ --ignore-missing-imports
    
    - name: Test with pytest
      run: |
        pytest tests/ --cov=src --cov-report=xml
    
    - name: Upload coverage
      uses: codecov/codecov-action@v3
```

---

**以上、実装ガイド**
