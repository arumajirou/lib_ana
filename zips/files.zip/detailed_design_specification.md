# Python ライブラリ解析システム V5 詳細設計書

**プロジェクト名**: Library Explorer & Analysis System (LEAS)  
**ドキュメント種別**: 詳細設計書  
**作成日**: 2026年2月5日  
**対象読者**: 開発者、アーキテクト

---

## 目次

1. [システムアーキテクチャ詳細](#1-システムアーキテクチャ詳細)
2. [モジュール設計](#2-モジュール設計)
3. [クラス設計](#3-クラス設計)
4. [データフロー](#4-データフロー)
5. [アルゴリズム詳細](#5-アルゴリズム詳細)
6. [UI設計詳細](#6-ui設計詳細)
7. [API仕様](#7-api仕様)
8. [データベーススキーマ](#8-データベーススキーマ)

---

## 1. システムアーキテクチャ詳細

### 1.1 レイヤー構造

```
┌─────────────────────────────────────────────────────────────┐
│                   Presentation Layer                         │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ ipywidgets UI (Jupyter Notebook)                      │  │
│  │ - CognitiveLibraryUIV5                                │  │
│  │ - TabManager                                          │  │
│  │ - WidgetFactory                                       │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                          ↓ (User Actions)
┌─────────────────────────────────────────────────────────────┐
│                   Application Layer                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Business Logic                                        │  │
│  │ - AnalysisOrchestrator                               │  │
│  │ - ValueCandidateGenerator                            │  │
│  │ - CodeGenerator                                      │  │
│  │ - SimilarityEngine                                   │  │
│  │ - ClusteringEngine                                   │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                          ↓ (Commands)
┌─────────────────────────────────────────────────────────────┐
│                    Domain Layer                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Domain Models                                         │  │
│  │ - Node, AnalysisResult, ParamValueHints              │  │
│  │ - PackageInventory, Cluster, SimilarityEdge          │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Domain Services                                       │  │
│  │ - ASTAnalyzer                                        │  │
│  │ - RuntimeAnalyzer                                    │  │
│  │ - FeatureExtractor                                   │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                          ↓ (Data Access)
┌─────────────────────────────────────────────────────────────┐
│                 Infrastructure Layer                         │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Data Access                                           │  │
│  │ - CacheStore                                         │  │
│  │ - FileExporter                                       │  │
│  │ - ConfigLoader                                       │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ External Libraries                                    │  │
│  │ - pkgutil, inspect, ast                              │  │
│  │ - pandas, plotly, pyvis                              │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 コンポーネント間通信

```
┌──────────┐     ┌──────────┐     ┌──────────┐
│   UI     │────>│Orchestr. │────>│Analyzer  │
│          │<────│          │<────│          │
└──────────┘     └──────────┘     └──────────┘
     │                │                 │
     │                │                 ↓
     │                │           ┌──────────┐
     │                │           │ Cache    │
     │                │           └──────────┘
     │                ↓
     │          ┌──────────┐
     └─────────>│ Export   │
                └──────────┘
```

**通信プロトコル**:
- UI → Orchestrator: イベント駆動（callbacks）
- Orchestrator → Analyzer: 同期呼び出し
- Analyzer → Cache: Read/Write
- UI → Export: ダイレクト呼び出し

---

## 2. モジュール設計

### 2.1 analyzer_v5.py

**責務**: ライブラリ解析の中核ロジック

**クラス構成**:

```python
class LibraryAnalyzerV5:
    """メインアナライザークラス"""
    
    def __init__(self, lib_name: str, config: AnalysisConfig):
        self.lib_name = lib_name
        self.cfg = config
        self.ast_analyzer = ASTAnalyzer(config)
        self.runtime_analyzer = RuntimeAnalyzer(config)
        self.value_generator = ValueCandidateGenerator()
        
    def analyze(self) -> AnalysisResult:
        """解析実行"""
        # 1. モジュール探索
        modules = self.discover_modules()
        
        # 2. AST解析
        ast_nodes = self.ast_analyzer.analyze_modules(modules)
        
        # 3. Runtime解析（オプション）
        if self.cfg.dynamic_import:
            runtime_nodes = self.runtime_analyzer.analyze_modules(modules)
            nodes = self.merge_nodes(ast_nodes, runtime_nodes)
        else:
            nodes = ast_nodes
        
        # 4. 値候補生成
        value_hints = self.value_generator.generate(nodes)
        
        # 5. 統計計算
        stats = self.calculate_stats(nodes)
        
        return AnalysisResult(
            lib_name=self.lib_name,
            nodes=nodes,
            value_hints=value_hints,
            stats=stats
        )
    
    def discover_modules(self) -> List[str]:
        """pkgutil.walk_packages でモジュール列挙"""
        pass
    
    def merge_nodes(self, ast_nodes, runtime_nodes) -> List[Node]:
        """AST と Runtime の情報をマージ"""
        pass
    
    def calculate_stats(self, nodes: List[Node]) -> Dict:
        """統計情報計算"""
        pass


class ASTAnalyzer:
    """AST静的解析"""
    
    def analyze_modules(self, modules: List[str]) -> List[Node]:
        """各モジュールをASTで解析"""
        nodes = []
        for mod_name in modules:
            file_path = self._find_source_file(mod_name)
            if file_path:
                mod_nodes = self._parse_ast(file_path, mod_name)
                nodes.extend(mod_nodes)
        return nodes
    
    def _parse_ast(self, file_path: str, mod_name: str) -> List[Node]:
        """ASTパース＋ノード抽出"""
        tree = ast.parse(Path(file_path).read_text())
        nodes = []
        
        for stmt in ast.walk(tree):
            if isinstance(stmt, ast.ClassDef):
                nodes.append(self._create_class_node(stmt, mod_name))
            elif isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                nodes.append(self._create_function_node(stmt, mod_name))
        
        return nodes


class RuntimeAnalyzer:
    """Runtime動的解析"""
    
    def analyze_modules(self, modules: List[str]) -> List[Node]:
        """各モジュールをimportして解析"""
        nodes = []
        for mod_name in modules:
            try:
                with timeout(30):  # タイムアウト
                    mod = importlib.import_module(mod_name)
                    mod_nodes = self._inspect_module(mod, mod_name)
                    nodes.extend(mod_nodes)
            except Exception as e:
                self.errors.append(f"Runtime import failed: {mod_name}: {e}")
        return nodes
    
    def _inspect_module(self, mod: Any, mod_name: str) -> List[Node]:
        """inspect でモジュールメンバー抽出"""
        pass


class ValueCandidateGenerator:
    """値候補生成エンジン"""
    
    def generate(self, nodes: List[Node]) -> Dict[str, ParamValueHints]:
        """全ノードの引数値候補を生成"""
        value_hints = {}
        global_defaults = self._collect_global_defaults(nodes)
        
        for node in nodes:
            if node.param_names:
                hints = self._generate_for_node(node, global_defaults)
                value_hints[node.id] = hints
        
        return value_hints
    
    def _generate_for_node(self, node: Node, global_defaults) -> ParamValueHints:
        """単一ノードの値候補生成"""
        candidates = []
        
        for param_name in node.param_names:
            # ソース1: デフォルト値
            if param_name in node.param_defaults:
                candidates.append(ParamValueCandidate(
                    value=node.param_defaults[param_name],
                    source='default',
                    confidence=0.95
                ))
            
            # ソース2: typing.Literal
            if param_name in node.param_types:
                literals = self._extract_literals(node.param_types[param_name])
                for lit in literals:
                    candidates.append(ParamValueCandidate(
                        value=lit,
                        source='literal',
                        confidence=0.90
                    ))
            
            # ソース3: Enum
            # ソース4: bool
            # ソース5: doc_summary
            # ソース6: global_defaults
            
        return ParamValueHints(
            param_name=param_name,
            candidates=sorted(candidates, key=lambda x: x.confidence, reverse=True)
        )
```

### 2.2 ui_v5.py

**責務**: ユーザーインターフェース

**クラス構成**:

```python
class CognitiveLibraryUIV5:
    """メインUIクラス"""
    
    def __init__(self):
        self.analyzer = None
        self.result = None
        self.selected_nodes = {}  # 各階層の選択状態
        
        # UI Components初期化
        self.tab_manager = TabManager(self)
        self.widget_factory = WidgetFactory()
        
        # タブ作成
        self.dashboard_tab = DashboardTab(self)
        self.explorer_tab = ExplorerTab(self)
        self.inspector_tab = InspectorTab(self)
        # ... 他のタブ
        
        # メインコンテナ
        self.container = widgets.VBox([
            self.create_header(),
            self.tab_manager.render()
        ])
    
    def display(self):
        """UI表示"""
        display(self.container)
    
    def on_analyze_clicked(self, lib_name: str):
        """解析ボタンクリック時"""
        self.analyzer = LibraryAnalyzerV5(lib_name, self.get_config())
        self.result = self.analyzer.analyze()
        self.update_all_tabs()


class ExplorerTab:
    """5階層ナビゲーションタブ"""
    
    def __init__(self, parent: CognitiveLibraryUIV5):
        self.parent = parent
        
        # 5階層のセレクトボックス
        self.modules_select = widgets.Select(rows=15)
        self.items_select = widgets.Select(rows=15)
        self.members_select = widgets.Select(rows=15)
        self.params_select = widgets.Select(rows=15)
        self.values_select = widgets.SelectMultiple(rows=15)
        
        # イベントハンドラ登録
        self.modules_select.observe(self.on_module_selected, 'value')
        self.items_select.observe(self.on_item_selected, 'value')
        self.members_select.observe(self.on_member_selected, 'value')
        self.params_select.observe(self.on_param_selected, 'value')
        
        self.container = widgets.HBox([
            self.modules_select,
            self.items_select,
            self.members_select,
            self.params_select,
            self.values_select
        ])
    
    def on_module_selected(self, change):
        """モジュール選択時のカスケード更新"""
        if not change['new']:
            return
        
        module_id = change['new']
        
        # 下流をクリア（選択ミス防止）
        self.items_select.value = None
        self.members_select.value = None
        self.params_select.value = None
        self.values_select.value = []
        
        # items を更新
        items = self._get_child_nodes(module_id)
        self.items_select.options = [(n.name, n.id) for n in items]
    
    def on_item_selected(self, change):
        """Item選択時のカスケード更新"""
        # 同様のロジック
        pass
    
    def on_member_selected(self, change):
        """Member選択時のカスケード更新"""
        # Params を更新
        pass
    
    def on_param_selected(self, change):
        """Param選択時の値候補更新"""
        # Values を更新
        pass


class InspectorTab:
    """詳細表示タブ"""
    
    def __init__(self, parent: CognitiveLibraryUIV5):
        self.parent = parent
        self.output = widgets.Output()
        
    def update(self, node_id: str):
        """選択ノードの詳細を表示"""
        self.output.clear_output()
        
        node = self.parent.result.get_node(node_id)
        
        with self.output:
            # 基本情報
            display(Markdown(f"## {node.fqn}"))
            display(Markdown(f"**Kind**: {node.kind}"))
            display(Markdown(f"**File**: {node.origin_file}:{node.lineno}"))
            
            # Docstring
            if node.doc_summary:
                display(Markdown("### Documentation"))
                display(Markdown(node.doc_summary))
            
            # シグネチャ
            if node.signature:
                display(Markdown("### Signature"))
                display(Code(node.signature, language='python'))
            
            # 引数テーブル
            if node.param_names:
                display(Markdown("### Parameters"))
                param_table = self._create_param_table(node)
                display(param_table)
            
            # 値候補テーブル（引数選択時）
            if self.parent.selected_nodes.get('param'):
                param_name = self.parent.selected_nodes['param']
                value_hints = self.parent.result.value_hints[node.id]
                value_table = self._create_value_table(value_hints, param_name)
                display(Markdown("### Value Candidates"))
                display(value_table)
    
    def _create_param_table(self, node: Node) -> pd.DataFrame:
        """引数テーブル作成"""
        rows = []
        for param in node.param_names:
            rows.append({
                'Name': param,
                'Type': node.param_types.get(param, 'Any'),
                'Default': node.param_defaults.get(param, '(required)'),
                'Kind': node.param_kinds.get(param, 'POSITIONAL_OR_KEYWORD')
            })
        return pd.DataFrame(rows)
    
    def _create_value_table(self, hints: ParamValueHints, param_name: str) -> pd.DataFrame:
        """値候補テーブル作成"""
        candidates = hints.candidates
        rows = []
        for cand in candidates:
            rows.append({
                'Value': cand.value,
                'Source': cand.source,
                'Confidence': f"{cand.confidence:.2f}",
                'Description': cand.description
            })
        return pd.DataFrame(rows)
```

### 2.3 codegen_v5.py

**責務**: サンプルコード生成

**クラス構成**:

```python
class CodeGenerator:
    """コード生成エンジン"""
    
    def __init__(self, data_factory: SampleDataFactory):
        self.data_factory = data_factory
    
    def generate(self, node: Node, selected_values: Dict[str, Any]) -> str:
        """サンプル実行コード生成"""
        code_lines = []
        
        # 1. Import文
        import_stmt = self._generate_import(node)
        code_lines.append(import_stmt)
        code_lines.append("")
        
        # 2. サンプルデータ生成（必要な場合）
        data_code = self._generate_sample_data(node, selected_values)
        if data_code:
            code_lines.extend(data_code)
            code_lines.append("")
        
        # 3. 呼び出しコード
        if node.kind == 'class':
            # クラスのインスタンス化
            init_code = self._generate_class_instantiation(node, selected_values)
            code_lines.append(init_code)
        elif node.kind in ['function', 'method']:
            # 関数呼び出し
            call_code = self._generate_function_call(node, selected_values)
            code_lines.append(call_code)
        
        # 4. 結果表示
        code_lines.append("print(result)")
        
        return "\n".join(code_lines)
    
    def _generate_import(self, node: Node) -> str:
        """Import文生成"""
        module = node.origin_module or node.fqn.rsplit('.', 1)[0]
        item = node.name
        return f"from {module} import {item}"
    
    def _generate_sample_data(self, node: Node, selected_values: Dict) -> List[str]:
        """サンプルデータ生成コード"""
        data_code = []
        
        for param_name, param_type in node.param_types.items():
            if self._needs_sample_data(param_type):
                sample = self.data_factory.generate(param_type, param_name)
                data_code.append(f"# Sample data for {param_name}")
                data_code.append(f"{param_name} = {sample}")
        
        return data_code
    
    def _generate_function_call(self, node: Node, selected_values: Dict) -> str:
        """関数呼び出しコード生成"""
        args = []
        
        for param in node.param_names:
            if param in selected_values:
                # ユーザー選択値
                value = selected_values[param]
                args.append(f"{param}={repr(value)}")
            elif param in node.param_defaults:
                # デフォルト値あり→省略
                continue
            else:
                # 必須引数→サンプル値
                sample = self.data_factory.generate_by_name(param)
                args.append(f"{param}={repr(sample)}")
        
        args_str = ", ".join(args)
        return f"result = {node.name}({args_str})"


class SampleDataFactory:
    """サンプルデータ生成"""
    
    def generate(self, type_hint: str, param_name: str = "") -> str:
        """型ヒントからサンプルデータ生成"""
        if 'DataFrame' in type_hint:
            return self._generate_dataframe(param_name)
        elif 'ndarray' in type_hint:
            return self._generate_ndarray(param_name)
        elif type_hint == 'str':
            return self._generate_string(param_name)
        elif type_hint == 'int':
            return "10"
        elif type_hint == 'float':
            return "0.5"
        elif type_hint == 'bool':
            return "True"
        # ... 他の型
        else:
            return "None"
    
    def _generate_dataframe(self, param_name: str) -> str:
        """DataFrame生成コード"""
        return """pd.DataFrame({
    'date': pd.date_range('2024-01-01', periods=100),
    'value': np.random.randn(100)
})"""
    
    def _generate_ndarray(self, param_name: str) -> str:
        """ndarray生成コード"""
        return "np.random.randn(10, 5)"
```

### 2.4 similarity.py

**責務**: 類似度計算

**クラス構成**:

```python
class SimilarityEngine:
    """類似度計算エンジン"""
    
    def __init__(self, feature_extractor: FeatureExtractor):
        self.feature_extractor = feature_extractor
        self.vectorizer = None
        self.vectors = None
    
    def build_index(self, nodes: List[Node]):
        """特徴量ベクトル構築"""
        # 1. 特徴量抽出
        features = [self.feature_extractor.extract(node) for node in nodes]
        
        # 2. TF-IDF ベクトル化
        from sklearn.feature_extraction.text import TfidfVectorizer
        
        # テキスト特徴（name + docstring）
        texts = [f"{f['name']} {f['doc']}" for f in features]
        self.vectorizer = TfidfVectorizer(max_features=1000)
        self.vectors = self.vectorizer.fit_transform(texts)
    
    def find_similar(self, node_id: str, top_k: int = 10, threshold: float = 0.3) -> List[SimilarityEdge]:
        """類似ノードを検索"""
        from sklearn.metrics.pairwise import cosine_similarity
        
        # クエリノードのベクトル
        query_idx = self._get_node_index(node_id)
        query_vec = self.vectors[query_idx]
        
        # 全ノードとの類似度計算
        scores = cosine_similarity(query_vec, self.vectors).flatten()
        
        # Top-K 取得（自身を除く）
        top_indices = scores.argsort()[::-1][1:top_k+1]
        
        edges = []
        for idx in top_indices:
            score = scores[idx]
            if score < threshold:
                continue
            
            target_id = self._get_node_id(idx)
            evidence = self._explain_similarity(query_idx, idx)
            
            edges.append(SimilarityEdge(
                source_id=node_id,
                target_id=target_id,
                score=score,
                evidence=evidence
            ))
        
        return edges
    
    def _explain_similarity(self, idx1: int, idx2: int) -> Dict:
        """類似度の根拠を説明"""
        # TF-IDF上位語を抽出
        feature_names = self.vectorizer.get_feature_names_out()
        
        vec1 = self.vectors[idx1].toarray().flatten()
        vec2 = self.vectors[idx2].toarray().flatten()
        
        # 共通して重要な語
        common_weights = vec1 * vec2
        top_indices = common_weights.argsort()[::-1][:5]
        
        keywords = [feature_names[i] for i in top_indices if common_weights[i] > 0]
        
        return {
            'keywords': keywords,
            'name_match': self._check_name_similarity(idx1, idx2),
            'signature_match': self._check_signature_similarity(idx1, idx2)
        }


class FeatureExtractor:
    """特徴量抽出"""
    
    def extract(self, node: Node) -> Dict:
        """ノードから特徴量抽出"""
        return {
            'name': self._tokenize_name(node.name),
            'doc': node.doc_summary,
            'signature': ' '.join(node.param_names),
            'types': ' '.join(node.param_types.values()),
            'kind': node.kind
        }
    
    def _tokenize_name(self, name: str) -> str:
        """名前のトークン化（snake_case, camelCase対応）"""
        # snake_case
        tokens = name.split('_')
        
        # camelCase
        import re
        camel_tokens = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)', name)
        
        all_tokens = tokens + camel_tokens
        return ' '.join(t.lower() for t in all_tokens if t)
```

---

## 3. クラス設計

### 3.1 主要クラス図

```mermaid
classDiagram
    class Node {
        +str id
        +str kind
        +str name
        +str fqn
        +str parent_id
        +str origin_module
        +Dict param_types
        +Dict param_defaults
        +List param_names
    }
    
    class AnalysisResult {
        +str lib_name
        +List~Node~ nodes
        +Dict value_hints
        +Dict global_defaults
        +List errors
    }
    
    class LibraryAnalyzerV5 {
        +str lib_name
        +AnalysisConfig cfg
        +analyze() AnalysisResult
        +discover_modules() List
    }
    
    class ValueCandidateGenerator {
        +generate(nodes) Dict
        -_extract_literals() List
        -_collect_global_defaults() Dict
    }
    
    class CodeGenerator {
        +SampleDataFactory data_factory
        +generate(node, values) str
        -_generate_import() str
        -_generate_function_call() str
    }
    
    class CognitiveLibraryUIV5 {
        +TabManager tab_manager
        +display()
        +on_analyze_clicked()
    }
    
    LibraryAnalyzerV5 --> AnalysisResult : creates
    LibraryAnalyzerV5 --> ValueCandidateGenerator : uses
    AnalysisResult --> Node : contains
    CodeGenerator --> Node : uses
    CognitiveLibraryUIV5 --> LibraryAnalyzerV5 : uses
```

---

## 4. データフロー

### 4.1 解析フロー

```
[User Input: Library Name]
         ↓
  ┌──────────────┐
  │ UI: Analyze  │
  │   Button     │
  └──────────────┘
         ↓
  ┌──────────────────────┐
  │ LibraryAnalyzerV5    │
  │ .analyze()           │
  └──────────────────────┘
         ↓
    ┌─────────┴─────────┐
    ↓                   ↓
┌─────────┐      ┌─────────────┐
│  AST    │      │  Runtime    │
│Analyzer │      │  Analyzer   │
└─────────┘      └─────────────┘
    ↓                   ↓
    └─────────┬─────────┘
              ↓
      ┌───────────────┐
      │  Merge Nodes  │
      └───────────────┘
              ↓
      ┌───────────────────┐
      │ ValueCandidate    │
      │   Generator       │
      └───────────────────┘
              ↓
      ┌───────────────┐
      │ AnalysisResult│
      └───────────────┘
              ↓
      ┌───────────────┐
      │ Cache Store   │
      └───────────────┘
              ↓
      ┌───────────────┐
      │ UI Update     │
      └───────────────┘
```

### 4.2 コード生成フロー

```
[User: Select API + Values]
         ↓
  ┌──────────────┐
  │ CodeGen Tab  │
  └──────────────┘
         ↓
  ┌──────────────────┐
  │ CodeGenerator    │
  │ .generate()      │
  └──────────────────┘
         ↓
    ┌────┴─────┬──────────┐
    ↓          ↓          ↓
┌────────┐ ┌────────┐ ┌────────┐
│Import  │ │Sample  │ │Call    │
│Gen     │ │Data    │ │Gen     │
└────────┘ └────────┘ └────────┘
    │          │          │
    └────┬─────┴──────────┘
         ↓
  ┌─────────────┐
  │ Format Code │
  │  (black)    │
  └─────────────┘
         ↓
  ┌─────────────┐
  │ Display     │
  │ + Copy      │
  └─────────────┘
```

---

## 5. アルゴリズム詳細

### 5.1 値候補生成アルゴリズム

```python
def generate_value_candidates(node: Node, global_defaults: Dict) -> List[ParamValueCandidate]:
    """
    引数値候補生成アルゴリズム
    
    優先順位:
    1. デフォルト値 (0.95)
    2. typing.Literal (0.90)
    3. Enum (0.85)
    4. bool型 (0.80)
    5. global_defaults (0.55)
    6. docstring解析 (0.35)
    """
    candidates = []
    
    for param_name, param_type in node.param_types.items():
        # ソース1: デフォルト値
        if param_name in node.param_defaults:
            default_val = node.param_defaults[param_name]
            candidates.append(
                ParamValueCandidate(default_val, 'default', 0.95)
            )
        
        # ソース2: typing.Literal
        if 'Literal' in param_type:
            literals = extract_literals(param_type)
            for lit in literals:
                candidates.append(
                    ParamValueCandidate(lit, 'literal', 0.90)
                )
        
        # ソース3: Enum
        if is_enum_type(param_type):
            enum_values = get_enum_values(param_type)
            for val in enum_values:
                candidates.append(
                    ParamValueCandidate(val, 'enum', 0.85)
                )
        
        # ソース4: bool
        if param_type == 'bool':
            candidates.extend([
                ParamValueCandidate(True, 'bool', 0.80),
                ParamValueCandidate(False, 'bool', 0.80)
            ])
        
        # ソース5: global_defaults
        if param_name in global_defaults:
            for val in global_defaults[param_name][:3]:  # 上位3つ
                candidates.append(
                    ParamValueCandidate(val, 'global_defaults', 0.55)
                )
        
        # ソース6: docstring解析
        doc_values = extract_from_docstring(node.doc_summary, param_name)
        for val in doc_values:
            candidates.append(
                ParamValueCandidate(val, 'doc_summary', 0.35)
            )
    
    # 重複排除＋確度順ソート
    unique_candidates = deduplicate_by_value(candidates)
    sorted_candidates = sorted(unique_candidates, 
                               key=lambda x: x.confidence, 
                               reverse=True)
    
    return sorted_candidates
```

### 5.2 類似度計算アルゴリズム

```python
def calculate_similarity(node1: Node, node2: Node, weights: Dict) -> float:
    """
    複合類似度計算
    
    重み:
    - name: 0.3
    - signature: 0.25
    - docstring: 0.25
    - type: 0.2
    """
    # 名前の類似度（編集距離ベース）
    name_sim = 1 - levenshtein_distance(node1.name, node2.name) / max(len(node1.name), len(node2.name))
    
    # シグネチャの類似度（Jaccard係数）
    params1 = set(node1.param_names)
    params2 = set(node2.param_names)
    sig_sim = len(params1 & params2) / len(params1 | params2) if params1 or params2 else 0
    
    # Docstringの類似度（TF-IDF cosine）
    doc_sim = cosine_similarity_tfidf(node1.doc_summary, node2.doc_summary)
    
    # 型の一致度
    type_sim = 1.0 if node1.kind == node2.kind else 0.0
    
    # 重み付き合計
    total_sim = (
        weights['name'] * name_sim +
        weights['signature'] * sig_sim +
        weights['docstring'] * doc_sim +
        weights['type'] * type_sim
    )
    
    return total_sim
```

---

## 6. UI設計詳細

### 6.1 5階層ナビゲーション詳細設計

**レイアウト**:
```
┌─────────────────────────────────────────────────────────────┐
│ [Search: ____________]  [Filter: ▼]  [Sort: ▼]             │
├─────────┬─────────┬─────────┬─────────┬─────────────────────┤
│Modules  │Items    │Members  │Params   │Values               │
│         │         │         │         │                     │
│○chronos │○ChronosT│○predict │○forecast│☑ 'mean'    (0.90)  │
│ ├model  │○Pipeline│○fit     │ horizon │☑ 'median'  (0.90)  │
│ ├utils  │○Config  │○save    │○verbose │☐ 10        (0.55)  │
│ └config │ ...     │ ...     │ ...     │☐ 100       (0.55)  │
│ ...     │         │         │         │☐ True      (0.35)  │
│         │         │         │         │☐ False     (0.35)  │
└─────────┴─────────┴─────────┴─────────┴─────────────────────┘
```

**カスケード更新ロジック**:
```python
def on_column_selected(column_index: int, selected_value: Any):
    """
    column_index: 0=Modules, 1=Items, 2=Members, 3=Params, 4=Values
    """
    # 1. 下流の列を全てクリア
    for i in range(column_index + 1, 5):
        clear_column(i)
    
    # 2. 次の列を更新
    if column_index < 4:
        next_options = get_child_options(column_index, selected_value)
        populate_column(column_index + 1, next_options)
    
    # 3. Inspectorを更新
    if column_index in [1, 2]:  # Items or Members
        update_inspector(selected_value)
```

### 6.2 Inspector タブレイアウト

```
┌─────────────────────────────────────────────────────────────┐
│ chronos.model.ChronosT5Model.predict                        │
├─────────────────────────────────────────────────────────────┤
│ **Kind**: method                                            │
│ **Module**: chronos.model.chronos_t5                        │
│ **File**: .../chronos/model/chronos_t5.py:125               │
├─────────────────────────────────────────────────────────────┤
│ ### Documentation                                           │
│ Generate forecasts for the given time series.               │
│ ...                                                          │
├─────────────────────────────────────────────────────────────┤
│ ### Signature                                               │
│ def predict(self, forecast_horizon: int = 10,               │
│             verbose: bool = False) -> np.ndarray            │
├─────────────────────────────────────────────────────────────┤
│ ### Parameters                                              │
│ ┌────────┬──────┬─────────┬──────────┬──────┐             │
│ │Name    │Type  │Default  │Kind      │Req'd │             │
│ ├────────┼──────┼─────────┼──────────┼──────┤             │
│ │forecast│int   │10       │POS_OR_KW │No    │             │
│ │verbose │bool  │False    │KEYWORD   │No    │             │
│ └────────┴──────┴─────────┴──────────┴──────┘             │
├─────────────────────────────────────────────────────────────┤
│ ### Value Candidates (for selected parameter)              │
│ ┌─────────┬─────────────┬──────────┬─────────────┐        │
│ │Value    │Source       │Confidence│Description  │        │
│ ├─────────┼─────────────┼──────────┼─────────────┤        │
│ │10       │default      │0.95      │Default value│        │
│ │100      │global_def   │0.55      │Common value │        │
│ │1000     │global_def   │0.55      │Common value │        │
│ └─────────┴─────────────┴──────────┴─────────────┘        │
└─────────────────────────────────────────────────────────────┘
```

---

## 7. API仕様

### 7.1 内部API

**LibraryAnalyzerV5.analyze()**
```python
def analyze(self) -> AnalysisResult:
    """
    ライブラリを解析してAnalysisResultを返す
    
    Returns:
        AnalysisResult: 解析結果
    
    Raises:
        ImportError: ライブラリがインポートできない場合
        ValueError: 設定が不正な場合
    """
```

**CodeGenerator.generate()**
```python
def generate(self, node: Node, selected_values: Dict[str, Any]) -> str:
    """
    サンプル実行コードを生成
    
    Args:
        node: 対象ノード
        selected_values: 引数名→選択値のマップ
    
    Returns:
        str: 実行可能なPythonコード
    """
```

### 7.2 公開API（将来的な拡張）

```python
# RESTful API (Phase 9以降)
GET  /api/v1/libraries/{lib_name}/analyze
POST /api/v1/libraries/analyze (body: {lib_name, config})
GET  /api/v1/libraries/{lib_name}/nodes
GET  /api/v1/libraries/{lib_name}/nodes/{node_id}
GET  /api/v1/libraries/{lib_name}/similar/{node_id}
POST /api/v1/codegen (body: {node_id, selected_values})
```

---

## 8. データベーススキーマ

### 8.1 キャッシュスキーマ（JSON）

**analysis_result_{snapshot_id}.json**
```json
{
  "lib_name": "chronos",
  "lib_version": "0.1.0",
  "snapshot_id": "chronos_0.1.0_20260205_123456",
  "timestamp": "2026-02-05T12:34:56Z",
  "nodes": [
    {
      "id": "chronos.model.ChronosT5Model",
      "kind": "class",
      "name": "ChronosT5Model",
      "fqn": "chronos.model.ChronosT5Model",
      "parent_id": "chronos.model",
      "origin_module": "chronos.model.chronos_t5",
      "origin_file": ".../chronos/model/chronos_t5.py",
      "lineno": 50,
      "end_lineno": 200,
      "signature": "",
      "param_names": [],
      "param_types": {},
      "param_defaults": {},
      "param_kinds": {},
      "return_type": null,
      "doc_summary": "Chronos T5-based forecasting model.",
      "doc_full": "...",
      "loc": 150,
      "flags": {
        "is_async": false,
        "is_property": false
      }
    },
    // ... 他のノード
  ],
  "value_hints": {
    "chronos.model.ChronosT5Model.predict": {
      "param_name": "forecast_horizon",
      "param_type": "int",
      "candidates": [
        {
          "value": 10,
          "source": "default",
          "confidence": 0.95,
          "description": "Default value"
        },
        // ...
      ]
    }
  },
  "global_defaults": {
    "verbose": [false, true],
    "n_jobs": [-1, 1, 4]
  },
  "errors": [],
  "warnings": [],
  "stats": {
    "total_modules": 15,
    "total_classes": 25,
    "total_functions": 120,
    "total_methods": 300
  }
}
```

### 8.2 設定スキーマ（YAML）

**api_overrides.yml**
```yaml
overrides:
  chronos:
    exclude_modules:
      - chronos.tests
      - chronos.internal
    include_only:
      - chronos.model.ChronosT5Model
      - chronos.utils.data_loader
  
  pandas:
    exclude_patterns:
      - ".*_.*"  # private
      - ".*test.*"
```

---

**以上、詳細設計書**
