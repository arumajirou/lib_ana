"""ui.lib_analysis.db

PostgreSQL 管理 + 可視化（ER図 / 依存グラフ / 統計）用のモジュール群。
Streamlit アプリは streamlit_app/ 配下。
"""
