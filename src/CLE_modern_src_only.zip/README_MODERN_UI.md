# CLE Modern Explorer（オフラインHTMLレポート版）

## 目的
- 解析結果の表（CSV/JSON）から、**モダンなオフラインHTML UI** を生成します。
- Jupyter/ipywidgets 依存を避け、ブラウザで快適に探索できます。

## 配置（要望どおり src 配下のみ）
- この zip から `ui_modern.py` を `C:\lib_ana\src\` にコピーしてください。
- 既存の `C:\lib_ana\lib\` (vis-network / tom-select) があれば見た目がより良くなります（CDNは使いません）。

## 使い方（推奨：既存V5の出力を入力にする）
あなたの tree だと、例として以下が存在します：
- `C:\lib_ana\outputs\api_tables\json_api.csv`

PowerShell:
```powershell
cd C:\lib_ana
python .\src\ui_modern.py --lib timesfm --input .\outputs\api_tables\json_api.csv
# 生成先: .\outputs\reports\timesfm_explorer.html
```

## 使い方（V4 analyzer が src にある場合：直接解析してUI生成）
```powershell
cd C:\lib_ana
python .\src\ui_modern.py --lib timesfm
```

## 成果物
- `outputs/api_tables/<lib>_nodes.csv`
- `outputs/api_tables/<lib>_nodes.json`
- `outputs/api_tables/<lib>_edges.json`
- `outputs/api_tables/<lib>_summary.json`
- `outputs/api_tables/<lib>.mmd`
- `outputs/reports/<lib>_explorer.html`
