from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

DEFAULT_WINDOWS_ROOT = r"C:\lib_ana"


@dataclass(frozen=True)
class Paths:
    root: Path
    data: Path
    cache: Path
    exports: Path
    logs: Path


def resolve_paths() -> Paths:
    env_root = os.getenv("LIB_ANA_ROOT", "").strip()
    if env_root:
        root = Path(env_root)
    else:
        root = Path.cwd() / "lib_ana"

    data = root / "data"
    cache = root / "cache"
    exports = root / "exports"
    logs = root / "logs"

    for p in (root, data, cache, exports, logs):
        p.mkdir(parents=True, exist_ok=True)

    return Paths(root=root, data=data, cache=cache, exports=exports, logs=logs)


def ensure_dirs() -> Paths:
    return resolve_paths()
