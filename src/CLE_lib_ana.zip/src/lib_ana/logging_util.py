from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat()


@dataclass
class RunContext:
    run_id: str
    snapshot_id: str
    log_path: Path


class JsonlLogger:
    def __init__(self, ctx: RunContext):
        self.ctx = ctx

    def log(self, step: str, status: str, **fields: Any) -> None:
        payload: Dict[str, Any] = {
            "ts": _now_iso(),
            "run_id": self.ctx.run_id,
            "snapshot_id": self.ctx.snapshot_id,
            "step": step,
            "status": status,
        }
        payload.update(fields)
        self.ctx.log_path.parent.mkdir(parents=True, exist_ok=True)
        with self.ctx.log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")


class StepTimer:
    def __init__(self, logger: JsonlLogger, step: str, extra: Optional[Dict[str, Any]] = None):
        self.logger = logger
        self.step = step
        self.extra = extra or {}
        self.t0 = 0.0

    def __enter__(self):
        self.t0 = time.perf_counter()
        self.logger.log(self.step, "start", **self.extra)
        return self

    def __exit__(self, exc_type, exc, tb):
        dt_ms = int((time.perf_counter() - self.t0) * 1000)
        if exc is None:
            self.logger.log(self.step, "ok", duration_ms=dt_ms, **self.extra)
            return False
        self.logger.log(self.step, "error", duration_ms=dt_ms, error_type=str(exc_type), error=str(exc), **self.extra)
        return False
