from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List

import pandas as pd


@dataclass(frozen=True)
class PipListParseResult:
    df: pd.DataFrame
    errors: List[str]


_PIP_COLUMNS_HEADER_RE = re.compile(r"^\s*Package\s+Version(\s+Editable\s+project\s+location)?\s*$", re.IGNORECASE)


def parse_pip_list_columns(text: str, snapshot_id: str, source_format: str = "pip_list_columns") -> PipListParseResult:
    lines = [ln.rstrip("\n") for ln in text.replace("\r\n", "\n").split("\n") if ln.strip()]
    errors: List[str] = []
    if not lines:
        return PipListParseResult(pd.DataFrame(), ["empty_input"])

    header_idx = None
    for i, ln in enumerate(lines[:8]):
        if _PIP_COLUMNS_HEADER_RE.match(ln):
            header_idx = i
            break
    if header_idx is None:
        header_idx = 0
        errors.append("header_not_found_assumed_first_line")

    data_start = header_idx + 1
    if data_start < len(lines) and set(lines[data_start]) <= {"-"}:
        data_start += 1

    rows = []
    for ln in lines[data_start:]:
        parts = re.split(r"\s{2,}", ln.strip())
        if len(parts) < 2:
            errors.append(f"cannot_parse_line: {ln}")
            continue
        package = parts[0]
        version = str(parts[1])
        editable_loc = parts[2] if len(parts) >= 3 else None
        rows.append(
            {
                "package": package,
                "version": version,
                "editable_project_location": editable_loc,
                "is_editable": bool(editable_loc),
                "snapshot_id": snapshot_id,
                "captured_at": datetime.now(timezone.utc).astimezone().isoformat(),
                "source_format": source_format,
                "raw_line": ln,
            }
        )

    return PipListParseResult(df=pd.DataFrame(rows), errors=errors)
