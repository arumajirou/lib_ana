from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd


@dataclass(frozen=True)
class CacheStore:
    base_dir: Path

    def path(self, name: str, snapshot_id: str, ext: str) -> Path:
        self.base_dir.mkdir(parents=True, exist_ok=True)
        return self.base_dir / f"{name}_{snapshot_id}.{ext.lstrip('.')}"

    def write_df(self, df: pd.DataFrame, name: str, snapshot_id: str) -> Path:
        p_parquet = self.path(name, snapshot_id, "parquet")
        try:
            df.to_parquet(p_parquet, index=False)
            return p_parquet
        except Exception:
            p_csv = self.path(name, snapshot_id, "csv")
            df.to_csv(p_csv, index=False, encoding="utf-8-sig")
            return p_csv

    def read_df(self, name: str, snapshot_id: str) -> pd.DataFrame:
        p_parquet = self.path(name, snapshot_id, "parquet")
        if p_parquet.exists():
            return pd.read_parquet(p_parquet)
        p_csv = self.path(name, snapshot_id, "csv")
        if p_csv.exists():
            return pd.read_csv(p_csv, encoding="utf-8-sig")
        raise FileNotFoundError(f"No cache found for {name} snapshot={snapshot_id}")

    def write_json(self, obj: Any, name: str, snapshot_id: str) -> Path:
        p = self.path(name, snapshot_id, "json")
        with p.open("w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
        return p

    def read_json(self, name: str, snapshot_id: str) -> Any:
        p = self.path(name, snapshot_id, "json")
        with p.open("r", encoding="utf-8") as f:
            return json.load(f)

    def write_text(self, text: str, name: str, snapshot_id: str, ext: str = "txt") -> Path:
        p = self.path(name, snapshot_id, ext)
        with p.open("w", encoding="utf-8") as f:
            f.write(text)
        return p
